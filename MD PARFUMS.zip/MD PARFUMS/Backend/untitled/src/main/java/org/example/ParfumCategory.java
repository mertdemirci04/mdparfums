package org.example;

public enum ParfumCategory {
    DESIGNER,
    NICHE
}
