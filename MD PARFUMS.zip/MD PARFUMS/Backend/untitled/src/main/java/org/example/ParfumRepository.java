package org.example;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface ParfumRepository extends JpaRepository<Parfum, Long> {
    List<Parfum> findByIsFeatured(boolean isFeatured);

    List<Parfum> findByCategory(ParfumCategory category);

    List<Parfum> findByNameContainingIgnoreCaseOrBrandContainingIgnoreCase(String nameKeyword, String brandKeyword);
}
