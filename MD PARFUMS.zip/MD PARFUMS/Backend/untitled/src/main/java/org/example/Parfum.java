package org.example;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Data
public class Parfum {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String brand;

    private double price;

    private String imageUrl;

    @Column(columnDefinition = "TEXT")
    private String description;


    private boolean isFeatured;

    @Enumerated(EnumType.STRING)
    private ParfumCategory category;

}
