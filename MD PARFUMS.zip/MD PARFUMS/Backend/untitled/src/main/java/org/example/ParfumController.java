package org.example;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/api/parfums")
@CrossOrigin(origins = "http://localhost:3000")
public class ParfumController {

    @Autowired
    private ParfumRepository parfumRepository;

    //Homepage
    @GetMapping("/featured")
    public List<Parfum> getFeaturedParfums() {
        return parfumRepository.findByIsFeatured(true);
    }

    //AllParfumsPage
    @GetMapping
    public List<Parfum> getAllParfums() {
        return parfumRepository.findAll();
    }

    // (CategoryPage)
    @GetMapping("/category/{categoryName}")
    public List<Parfum> getParfumsByCategory(@PathVariable String categoryName) {
        try {
            ParfumCategory category = ParfumCategory.valueOf(categoryName.toUpperCase());
            return parfumRepository.findByCategory(category);
        } catch (IllegalArgumentException e) {
            throw new ResponseStatusException(
                    HttpStatus.NOT_FOUND, "Invalid Category Name: " + categoryName
            );
        }
    }


    //ProductDetail Page
    @GetMapping("/{id}")
    public Parfum getParfumById(@PathVariable Long id) {
        return parfumRepository.findById(id).orElseThrow(() -> new ResponseStatusException(
                HttpStatus.NOT_FOUND, "Not found Id of Parfums" + id
        ));
    }

    @GetMapping("/search")
    public List<Parfum> searchParfums(@RequestParam String query) {
        if (query == null || query.trim().isEmpty()) {
            return List.of();
        }

        //Letter Set
        return parfumRepository.findByNameContainingIgnoreCaseOrBrandContainingIgnoreCase(query, query);
    }


}