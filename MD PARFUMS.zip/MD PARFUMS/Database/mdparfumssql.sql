CREATE DATABASE parfums_db;
USE parfums_db;

-- WARNING: This will delete all existing data
TRUNCATE TABLE parfum; 


INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Dior', 'DESIGNER', 'Woody and refreshing men’s perfume.', '/images/dior-sauvage.png', 1, 'Sauvage', 550.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Creed', 'NICHE', 'A luxurious, smoky, fruity, and woody fragrance.', '/images/creed-aventus.png', 1, 'Aventus', 600.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Dolce & Gabbana', 'DESIGNER', 'A fresh, floral, and fruity summer scent.', '/images/light-blue.png', 0, 'Light Blue', 450.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Maison Francis Kurkdjian', 'NICHE', 'A signature fragrance with sweet, mineral, and amber notes.', '/images/baccarat.jpg', 1, 'Baccarat Rouge 540', 700.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Giorgio Armani', 'DESIGNER', 'An aquatic and aromatic men’s classic.', '/images/acquadi-gio.jpg', 1, 'Acqua di Gio', 550.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Chanel', 'DESIGNER', 'A magnificent harmony of woody and citrus notes.', '/images/bluedechanel.jpg', 0, 'Bleu De Chanel', 500.00);


-- NEW 10 DESIGNER PERFUMES

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('YSL', 'DESIGNER', 'A modern, sweet, iconic women’s perfume with notes of coffee and vanilla.', '/images/ysl-black-opium.png', 0, 'Black Opium', 450.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Chanel', 'DESIGNER', 'An elegant, powdery, floral classic infused with aldehydes.', '/images/chanel-no5.png', 0, 'No. 5', 450.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Paco Rabanne', 'DESIGNER', 'A spicy, leathery, sweet, and woody men’s fragrance.', '/images/paco-invictus.png', 1, 'Invictus', 500.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Guerlain', 'DESIGNER', 'A sunny, warm fragrance with coconut notes.', '/images/guerlain-id.png', 0, 'Mon Guerlain', 650.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Tom Ford', 'DESIGNER', 'A refreshing summer fragrance with mandarin, orange blossom, and jasmine notes.', '/images/tom-ford-neroli.png', 1, 'Neroli Portofino', 600.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Hermès', 'DESIGNER', 'A unique men’s fragrance with earthy, mineral, and woody notes.', '/images/hermes-terre.png', 1, 'Terre d’Hermès', 500.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Mugler', 'DESIGNER', 'An intense gourmand fragrance with sweet, patchouli, and caramel notes.', '/images/mugler-angel.png', 0, 'Angel', 500.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Jean Paul Gaultier', 'DESIGNER', 'A sweet oriental fragrance featuring mint, lavender, and vanilla.', '/images/jpg-le-male.png', 1, 'Le Male', 600.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Versace', 'DESIGNER', 'A powerful, masculine, and refreshing scent with lime and ambroxan.', '/images/versace-eros.png', 1, 'Eros', 400.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Givenchy', 'DESIGNER', 'A feminine and elegant fragrance with powdery, jasmine, and vetiver notes.', '/images/givenchy-inter.png', 0, 'L’Interdit', 500.00);


-- NEW 10 NICHE PERFUMES

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Parfums de Marly', 'NICHE', 'An oriental men’s perfume with vanilla, sandalwood, and spicy notes.', '/images/pdm-layton.png', 1, 'Layton', 600.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Amouage', 'NICHE', 'A powerful oriental fragrance with intense incense, spices, and rose.', '/images/amouage-interlude.png', 1, 'Interlude Man', 650.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Byredo', 'NICHE', 'A minimalist scent with woody, musk, and fresh rose notes.', '/images/byredo-baldaf.png', 0, 'Bal d’Afrique', 600.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Memo Paris', 'NICHE', 'An exotic leathery fragrance with deep leather and warm spices.', '/images/memo-italian.png', 1, 'Irish Leather', 700.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Initio Parfums', 'NICHE', 'A powerful blend of musk, vanilla, and amber with aphrodisiac effects.', '/images/initio-addiction.png', 0, 'Oud for Greatness', 700.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Tiziana Terenzi', 'NICHE', 'A bold unisex fragrance with sweet, patchouli, and woody notes.', '/images/tiziana-kirke.png', 1, 'Kirke', 550.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Kilian', 'NICHE', 'A sweet gourmand oriental fragrance with rum, caramel, and vanilla.', '/images/kilian-straight.png', 0, 'Straight to Heaven', 600.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Tom Ford', 'NICHE', 'A rich, warm, and luxurious blend of tobacco leaf, spices, and vanilla.', '/images/tomford-tobacco.png', 1, 'Tobacco Vanille', 650.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Xerjoff', 'NICHE', 'A rare, warm, and unique fragrance with milk, caramel, and orange notes.', '/images/xerjoff-lr.png', 0, 'Lira', 500.00);

INSERT INTO parfum (brand, category, description, image_url, is_featured, name, price)
VALUES ('Frederic Malle', 'NICHE', 'A modern chypre classic featuring intense rose and patchouli.', '/images/fm-portrait.png', 0, 'Portrait of a Lady', 500.00);
