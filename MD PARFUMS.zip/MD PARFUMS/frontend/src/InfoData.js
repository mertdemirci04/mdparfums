// src/InfoData.js

export const INFO_PAGES = {
    "/kvkk": {
        title: "Personal Data Protection Law (KVKK)",
        content: "In accordance with the Personal Data Protection Law (KVKK), your personal data is securely encrypted and protected within the legal framework. Your data is not shared with third parties without your consent. For detailed information, please review our official KVKK policy."
    },
    "/gizlilik": {
        title: "Privacy Policy",
        content: "This policy provides information about how your personal data is collected, used, and protected. By accessing our website, you are deemed to have accepted our privacy terms. Your payment information is protected with 256-bit SSL encryption."
    },
    "/cerez": {
        title: "Cookie Policy",
        content: "Our website uses cookies to improve user experience and analyze traffic. You can manage your cookie preferences through your browser settings. By continuing to use our website, you consent to the use of cookies."
    },
    "/satis-sozlesmesi": {
        title: "Sales Policy Agreement",
        content: "The delivery, return, and warranty conditions of the products you purchase are covered under this agreement. The return period is 14 business days from the date of delivery. Please read all terms carefully before placing an order."
    },
    "/yardim": {
        title: "Help Center",
        content: "We are available 24/7 for order tracking, product returns, payment issues, and other technical support matters. For live support, you can send an email to 'info@mdparfums.com'."
    },
    "/oneriler": {
        title: "Requests & Suggestions",
        content: "Your feedback is very valuable for the growth of our brand. You can share all your suggestions regarding our products, website, or services via the contact form. All requests are reviewed within 48 hours at the latest."
    },
    "/takip": {
        title: "Order Tracking",
        content: "After logging in, you can track the current status of your order, shipment details, and estimated delivery date in real time under the 'My Orders' section in the 'My Profile' menu."
    },
    "/info": {
        title: "About Us / Perfume Information",
        content: "As MD Parfums, our goal is to offer a high-quality alternative perfume experience at the most affordable prices. Our products are manufactured in compliance with the Ministry of Health regulations and meet the highest raw material standards. Please note that longevity may vary depending on skin type, season, and perfume composition."
    },
    "/iletisim": {
        title: "Contact",
        content: "Address: Altunizade, Kuşbakışı St. No:2, 34662 Üsküdar/Istanbul. Phone: +90 553 804 78 90. Email: info@mdparfums.com."
    },
};
