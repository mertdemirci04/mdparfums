// src/components/AllParfumsPage.js
import React, { useState, useEffect, useMemo } from 'react';
import axios from 'axios';
import { Container, Typography, Grid, CircularProgress, Alert, Box, Paper, Divider, FormControl, InputLabel, Select, MenuItem, Slider } from '@mui/material'; 
import ParfumCard from './ParfumCard';

// Backend API 
const API_URL = 'http://localhost:8080/api/parfums'; 

// Take the review from Local
const getAllReviews = () => {
    return JSON.parse(localStorage.getItem('all_product_reviews') || '{}');
};

const AllParfumsPage = () => {
    const [parfums, setParfums] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    
    const [selectedBrand, setSelectedBrand] = useState('All');
    const [priceRange, setPriceRange] = useState([50, 500]); 
    const [sortBy, setSortBy] = useState('priceAsc');
    
    const reviews = useMemo(() => getAllReviews(), []);

    useEffect(() => {
        axios.get(API_URL) 
            .then(response => {
                setParfums(response.data);
                setLoading(false);
            })
            .catch(err => {
                console.error("Data extraction error:", err);
                setError("An error occurred while uploading the products.");
                setLoading(false);
            });
    }, []); 

    const uniqueBrands = useMemo(() => {
        const brands = parfums.map(p => p.brand);
        
        const distinctBrands = [...new Set(brands)];
        
        distinctBrands.sort();
        
        return ['All', ...distinctBrands];
    }, [parfums]);

    const filteredAndSortedParfums = useMemo(() => {
        let currentParfums = [...parfums];

        if (selectedBrand !== 'All') {
            currentParfums = currentParfums.filter(p => p.brand === selectedBrand);
        }
        
        currentParfums = currentParfums.filter(p => {
            const basePrice = p.price;
            return basePrice >= priceRange[0] && basePrice <= priceRange[1];
        });
        
        //Sorting
        currentParfums.sort((a, b) => {
            if (sortBy === 'mostReviews') {
                const countA = reviews[a.id]?.length || 0;
                const countB = reviews[b.id]?.length || 0;
                return countB - countA;
            }
            if (sortBy === 'priceAsc') return a.price - b.price;
            if (sortBy === 'priceDesc') return b.price - a.price;
            if (sortBy === 'nameAsc') return a.name.localeCompare(b.name);
            return 0; 
        });

        return currentParfums;
    }, [parfums, selectedBrand, priceRange, sortBy, reviews]);
    // ----------------------------------------------------

    if (loading) {
        return <Container sx={{ textAlign: 'center', mt: 5 }}><CircularProgress color="primary" /></Container>;
    }

    if (error) {
        return <Container sx={{ mt: 5 }}><Alert severity="error">{error}</Alert></Container>;
    }
    
    const minPriceDynamic = Math.floor(parfums.reduce((min, p) => Math.min(min, p.price), 50));
    const maxPriceDynamic = Math.ceil(parfums.reduce((max, p) => Math.max(max, p.price), 500));


    return (
        <Container maxWidth="lg" sx={{ mt: 4, mb: 8 }}>
            <Typography variant="h4" component="h1" gutterBottom color="primary" sx={{ fontWeight: 700, mb: 4 }}>
                ALL Fragrances ({filteredAndSortedParfums.length} / {parfums.length})
            </Typography>

            <Paper sx={{ p: 2, mb: 3, display: 'flex', flexWrap: 'wrap', gap: 3, alignItems: 'center' }} elevation={1}>
                
                <Typography variant="subtitle1" sx={{ fontWeight: 600, minWidth: 80 }}>Filtreler:</Typography>

                <FormControl variant="outlined" size="small" sx={{ minWidth: 150 }}>
                    <InputLabel>Brand</InputLabel>
                    <Select
                        value={selectedBrand}
                        label="Brand"
                        onChange={(e) => setSelectedBrand(e.target.value)}
                    >
                        {uniqueBrands.map(brand => (
                            <MenuItem key={brand} value={brand}>{brand}</MenuItem>
                        ))}
                    </Select>
                </FormControl>

                <Box sx={{ minWidth: 250 }}>
                    <Typography variant="caption" display="block">
                        Price: 
                        <Box component="span" sx={{ fontWeight: 600, ml: 1 }}>
                            {priceRange[0]} TL - {priceRange[1]} TL
                        </Box>
                    </Typography>
                    <Slider
                        value={priceRange}
                        onChange={(e, newValue) => setPriceRange(newValue)}
                        valueLabelDisplay="auto"
                        min={minPriceDynamic}
                        max={maxPriceDynamic}
                        step={10}
                        size="small"
                        sx={{ mt: 1, height: 4 }}
                    />
                </Box>
                
                <FormControl variant="outlined" size="small" sx={{ minWidth: 180 }}>
                    <InputLabel>Sort by</InputLabel>
                    <Select
                        value={sortBy}
                        label="Sort by"
                        onChange={(e) => setSortBy(e.target.value)}
                    >
                        <MenuItem value="mostReviews">Most Commented</MenuItem>
                        <MenuItem value="priceAsc">Price (Cheapest)</MenuItem>
                        <MenuItem value="priceDesc">Price (Most Expensive)</MenuItem>
                        <MenuItem value="nameAsc">Name (A-Z)</MenuItem>
                    </Select>
                </FormControl>

            </Paper>

            {/* Product List */}
            <Grid container spacing={4} justifyContent="start">
                {filteredAndSortedParfums.length > 0 ? (
                    filteredAndSortedParfums.map((parfum) => (
                        <Grid item key={parfum.id} xs={12} sm={6} md={4} lg={3}> 
                            <ParfumCard parfum={parfum} />
                        </Grid>
                    ))
                ) : (
                    <Box sx={{ p: 3 }}>
                        <Alert severity="warning">No perfume matching the selected criteria was found.</Alert>
                    </Box>
                )}
            </Grid>
        </Container>
    );
};

export default AllParfumsPage;