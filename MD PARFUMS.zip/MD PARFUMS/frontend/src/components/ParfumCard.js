// src/components/ParfumCard.js
import React from 'react';
import { Card, CardContent, CardMedia, Typography, Button, Box } from '@mui/material';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { Link as RouterLink } from 'react-router-dom';
import { useCart } from './CartContext'; 

const ParfumCard = ({ parfum }) => {
    const { addToCart } = useCart();

    const isNicheDiscounted = parfum.category === 'NICHE';
    const originalPrice = isNicheDiscounted 
        ? (parfum.price / 0.80).toFixed(2) 
        : null;

    const currentPrice = parfum.price.toFixed(2);
    
    const handleAddToCart = () => {
        addToCart(parfum);
    };

    return (
        <Card sx={{ height: '100%', display: 'flex', flexDirection: 'column', transition: '0.3s', '&:hover': { boxShadow: 6 } }}>
            <CardMedia
                component={RouterLink}
                to={`/product/${parfum.id}`}
                image={parfum.imageUrl || '/placeholder.jpg'}
                title={parfum.name}
                sx={{ pt: '100%', cursor: 'pointer', objectFit: 'cover' }}
            />
            <CardContent sx={{ flexGrow: 1, p: 2 }}>
                
                {/* DISCOUNT TAG */}
                {isNicheDiscounted && (
                    <Box sx={{ mb: 1, bgcolor: 'error.main', color: 'white', display: 'inline-block', p: '2px 8px', borderRadius: 1 }}>
                        <Typography variant="caption" sx={{ fontWeight: 700 }}>
                            20% OFF
                        </Typography>
                    </Box>
                )}

                <Typography gutterBottom variant="h6" component="div" sx={{ fontWeight: 600 }}>
                    {parfum.name}
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ mb: 1 }}>
                    {parfum.brand}
                </Typography>

                {/* PRICE DISPLAY */}
                <Box sx={{ display: 'flex', alignItems: 'center', minHeight: 28, mb: -2 }}>
                    {isNicheDiscounted && (
                        <Typography 
                            variant="subtitle1" 
                            color="text.secondary" 
                            sx={{ textDecoration: 'line-through', mr: 1, fontSize: '0.9rem' }}
                        >
                            {originalPrice}
                        </Typography>
                    )}
                    
                    <Typography 
                        variant="h6" 
                        color={isNicheDiscounted ? 'error.main' : 'primary.dark'} 
                        sx={{ fontWeight: 700 }}
                    >
                        {currentPrice} TL
                    </Typography>
                </Box>
            </CardContent>
            
            <Box sx={{ p: 2, pt: 0 }}>
                <Button
                    fullWidth
                    variant="contained"
                    color="primary"
                    startIcon={<ShoppingCartIcon />}
                    onClick={handleAddToCart}
                >
                    Add to Cart
                </Button>
            </Box>
        </Card>
    );
};

export default ParfumCard;