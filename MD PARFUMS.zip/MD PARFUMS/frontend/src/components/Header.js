// src/components/Header.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Link as RouterLink, useNavigate } from 'react-router-dom';
import { 
    AppBar, Toolbar, Typography, Box, Button, TextField, InputAdornment, IconButton, Paper, 
    Grid, Menu, MenuItem, Container, Badge, Divider
} from '@mui/material';
import SearchIcon from '@mui/icons-material/Search';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import AccountCircle from '@mui/icons-material/AccountCircle'; 
import LocalOfferIcon from '@mui/icons-material/LocalOffer'; 
import KeyboardArrowDownIcon from '@mui/icons-material/KeyboardArrowDown';
import { useCart } from './CartContext'; 
import { useAuth } from './AuthContext'; 

// Categories and Route Definitions
const categories = [
    { name: 'All Perfumes', path: '/parfum' }, 
    { name: 'Niche Perfumes', path: '/category/niche' }, 
    { name: 'Designer Perfumes', path: '/category/designer' },
    { name: 'Perfume Information', path: '/info' } 
];

// Single search result card LIVE SEARCH
const SearchResultCard = ({ parfum, onClick }) => (
    <Box 
        sx={{ p: 1, display: 'flex', alignItems: 'center', cursor: 'pointer', '&:hover': { bgcolor: '#f0f0f0' } }}
        onClick={onClick}
    >
        <img src={parfum.imageUrl || 'placeholder.jpg'} alt={parfum.name} style={{ width: 40, height: 40, marginRight: 8, borderRadius: 3 }} />
        <Box>
            <Typography variant="body2" sx={{ fontWeight: 600 }}>{parfum.name}</Typography>
            <Typography variant="caption" color="text.secondary">{parfum.brand}</Typography>
        </Box>
    </Box>
);

const Header = () => {
    const navigate = useNavigate(); 
    const { cartItems } = useCart();
    const { user, isAuthenticated, logout } = useAuth(); 
    
    const [searchTerm, setSearchTerm] = useState(''); 
    const [searchResults, setSearchResults] = useState([]);
    const [isSearching, setIsSearching] = useState(false);
    const [anchorEl, setAnchorEl] = useState(null); 
    const open = Boolean(anchorEl);

    const cartItemCount = cartItems.reduce((count, item) => count + item.quantity, 0);

    // --- PROFILE AND NAVIGATION FUNCTIONS ---
    const handleMenu = (event) => {
        if (isAuthenticated) {
            setAnchorEl(event.currentTarget);
        } else {
            navigate('/login');
        }
    };

    const handleClose = () => {
        setAnchorEl(null);
    };

    const handleLogout = () => {
        logout();
        handleClose();
        navigate('/'); 
    };

    const handleNavigation = (path) => {
        handleClose();
        navigate(path);
    };
    // ---------------------------------

    // --- SEARCH FUNCTIONS ---
    useEffect(() => {
        const fetchResults = async () => {
             const query = searchTerm.trim();
             if (query.length < 2) {
                 setSearchResults([]);
                 setIsSearching(false);
                 return;
             }
             setIsSearching(true);
             try {
                 const API_URL = `http://localhost:8080/api/parfums/search?query=${query}`;
                 const response = await axios.get(API_URL);
                 setSearchResults(response.data.slice(0, 8)); 
             } catch (error) {
                 console.error("Search API error:", error);
                 setSearchResults([]);
             } finally {
                 setIsSearching(false);
             }
         };
 
         const timeoutId = setTimeout(() => { 
             fetchResults();
         }, 300);
 
         return () => clearTimeout(timeoutId); 
    }, [searchTerm]);

    const handleFullSearch = () => {
        if (searchTerm.trim()) {
            setSearchResults([]); 
            navigate(`/search?query=${searchTerm.trim()}`); 
        }
    };

    const handleProductClick = (id) => {
        setSearchResults([]); 
        setSearchTerm(''); 
        navigate(`/product/${id}`); 
    };


    return (
        <AppBar position="sticky" sx={{ bgcolor: 'white', color: 'primary.main', boxShadow: 3 }}>
            
            {/* 1. TOP BAR – Announcements and Discounts */}
            <Box sx={{ bgcolor: '#333', color: 'white', py: 0.5, display: { xs: 'none', sm: 'block' } }}>
                <Container maxWidth="lg">
                    <Typography variant="caption" sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center' }}>
                        <LocalOfferIcon fontSize="small" sx={{ mr: 0.5, color: '#ffb300' }} />
                        Don’t miss 10%, 15%, 20% discounts on Niche Perfumes! | FREE SHIPPING on orders over 1000 TL!
                    </Typography>
                </Container>
            </Box>

            {/* 2. MAIN BAR – Logo, Search, Icons */}
            <Container maxWidth="lg">
                <Toolbar disableGutters sx={{ 
                    minHeight: { xs: '64px', md: '72px' }, 
                    position: 'relative',
                    alignItems: 'center', 
                    justifyContent: 'space-between', 
                }}> 
                    
                    {/* 1. Logo / Site Name and Image */}
                    <Box 
                        component={RouterLink} 
                        to="/"
                        sx={{ 
                            display: 'flex', 
                            alignItems: 'center', 
                            textDecoration: 'none', 
                            color: 'primary.main',
                            minWidth: 160
                        }}
                    >
                        {/* Logo Image */}
                        <Box
                            component="img"
                            src="/images/logo.png"
                            alt="MD Parfums Logo"
                            sx={{
                                height: 62,
                                mr: 2,
                                
                            }}
                        />
                         <Typography 
                            variant="h5" 
                            color="primary" 
                            sx={{ fontWeight: 800, cursor: 'pointer', textDecoration: 'none' }} 
                        >
                            MD Parfums
                        </Typography>
                    </Box>

                    {/* 2. Search Bar and RESULTS BOX */}
                    <Box sx={{ 
                        flexGrow: 1, 
                        display: { xs: 'none', md: 'flex' }, 
                        alignItems: 'center',
                        position: 'relative', 
                        maxWidth: 700,
                        mx: { md: 2, lg: 4 }
                    }}>
                        <TextField
                            placeholder="Search by brand, name, or notes..."
                            size="small"
                            variant="outlined"
                            fullWidth
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                            onKeyDown={(e) => { 
                                if (e.key === 'Enter') { handleFullSearch(); }
                            }}
                            sx={{ bgcolor: '#f5f5f5', borderRadius: 1, transition: '0.3s', '&:focus-within': { bgcolor: 'white', boxShadow: 1 } }}
                            InputProps={{
                                startAdornment: (
                                    <InputAdornment position="start">
                                        <IconButton size="small" color="primary" onClick={handleFullSearch}>
                                            <SearchIcon />
                                        </IconButton>
                                    </InputAdornment>
                                ),
                            }}
                        />
                        
                        {/* Search Results Box (Pop-up) */}
                        {(searchResults.length > 0 || isSearching) && searchTerm.length >= 2 && (
                            <Paper 
                                elevation={5} 
                                sx={{ 
                                    position: 'absolute', top: 45, left: 0, right: 0,
                                    zIndex: 10, maxHeight: 350, overflowY: 'auto'
                                }}
                            >
                                {isSearching && (
                                    <Box sx={{ p: 2, textAlign: 'center' }}>
                                        <Typography variant="body2">Searching...</Typography>
                                    </Box>
                                )}
                                <Grid container>
                                    {searchResults.map((parfum) => (
                                        <Grid item xs={12} key={parfum.id}> 
                                            <SearchResultCard 
                                                parfum={parfum} 
                                                onClick={() => handleProductClick(parfum.id)}
                                            />
                                            <Divider />
                                        </Grid>
                                    ))}
                                </Grid>
                                <Box sx={{ p: 1, borderTop: '1px solid #eee' }}>
                                    <Button fullWidth variant="text" size="small" onClick={handleFullSearch}>
                                        View All Results ({searchResults.length}+)
                                    </Button>
                                </Box>
                            </Paper>
                        )}
                    </Box>

                    {/* 3. Icons (Cart and User) */}
                    <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        
                        {/* User Name or Login Message */}
                        {isAuthenticated && (
                            <Typography variant="body2" color="primary" sx={{ mr: 1, display: { xs: 'none', sm: 'block' } }}>
                                Hello, {user.name ? user.name.split(' ')[0] : 'User'}
                            </Typography>
                        )}

                        {/* Profile Icon and Menu Trigger (Enlarged) */}
                        <IconButton 
                            color="primary" 
                            onClick={handleMenu} 
                            size="large"
                            sx={{ p: 1.5 }}
                        >
                            <AccountCircle sx={{ fontSize: '2rem' }} /> 
                        </IconButton>
                        
                        {/* Cart Icon */}
                        <IconButton 
                            color="primary" 
                            component={RouterLink} 
                            to="/sepet"
                            size="large"
                            sx={{ ml: 1, p: 1.5 }}
                        >
                            <Badge badgeContent={cartItemCount} color="error">
                                <ShoppingCartIcon sx={{ fontSize: '2rem' }} />
                            </Badge>
                        </IconButton>

                        {/* Profile Menu */}
                        <Menu
                            id="menu-appbar"
                            anchorEl={anchorEl}
                            anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                            keepMounted
                            transformOrigin={{ vertical: 'top', horizontal: 'right' }}
                            open={open}
                            onClose={handleClose}
                        >
                            <MenuItem onClick={() => handleNavigation('/profil')}>My Profile</MenuItem>
                            <MenuItem onClick={() => handleNavigation('/siparislerim')}>My Orders</MenuItem>
                            <MenuItem onClick={() => handleNavigation('/profil/ayarlar')}>Settings</MenuItem>
                            <Divider />
                            <MenuItem onClick={handleLogout} sx={{ color: 'error.main' }}>Log Out</MenuItem>
                        </Menu>
                    </Box>
                </Toolbar>
            </Container>
            
            {/* 3. BOTTOM BAR (Navigation Bar) – Categories */}
            <Box sx={{ bgcolor: 'secondary.main', display: { xs: 'none', md: 'block' } }}>
                <Container maxWidth="lg">
                    <Toolbar component="nav" sx={{ minHeight: '40px', py: 0, justifyContent: 'center' }}>
                        {categories.map((category) => (
                            <Button 
                                key={category.name} 
                                color="inherit" 
                                component={RouterLink} 
                                to={category.path} 
                                endIcon={category.name === 'Niche Perfumes'}
                                sx={{ 
                                    mx: 1, 
                                    fontWeight: 600, 
                                    textDecoration: 'none',
                                    '&:hover': { bgcolor: 'rgba(255, 255, 255, 0.1)' }
                                }}
                            >
                                {category.name}
                            </Button>
                        ))}
                    </Toolbar>
                </Container>
            </Box>
        </AppBar>
    );
};

export default Header;
