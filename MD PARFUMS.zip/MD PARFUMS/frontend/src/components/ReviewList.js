// src/components/ReviewList.js
import React from 'react';
import { Box, Typography, Rating, Divider, List, ListItem, ListItemText, Avatar, Alert } from '@mui/material';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';

const ReviewList = ({ reviews }) => {
    
    const totalReviews = reviews.length;
    const averageRating = totalReviews 
        ? (reviews.reduce((sum, review) => sum + review.rating, 0) / totalReviews).toFixed(1)
        : 0;

    return (
        <Box sx={{ mt: 4, pt: 3 }}>
            <Typography variant="h5" component="h2" sx={{ fontWeight: 600, mb: 3 }}>
                Customer Reviews ({totalReviews})
            </Typography>

            {/* Average Rating Box */}
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 3, p: 2, bgcolor: '#f9f9f9', borderRadius: 1 }}>
                <Rating value={parseFloat(averageRating)} precision={0.1} readOnly size="large" sx={{ mr: 2 }} />
                <Typography variant="h4" sx={{ fontWeight: 700, color: 'primary.main' }}>
                    {averageRating} / 5
                </Typography>
                <Typography variant="body2" color="text.secondary" sx={{ ml: 1 }}>
                    ({totalReviews} ratings)
                </Typography>
            </Box>

            {/* Reviews List */}
            {totalReviews === 0 ? (
                <Alert severity="info">This product hasn't been reviewed yet. Be the first to review!</Alert>
            ) : (
                <List>
                    {reviews.map((review) => (
                        <Box key={review.id}>
                            <ListItem alignItems="flex-start" sx={{ px: 0 }}>
                                <Avatar sx={{ bgcolor: 'secondary.main', mr: 2 }}>
                                    <AccountCircleIcon />
                                </Avatar>
                                <ListItemText
                                    primary={
                                        <Box display="flex" alignItems="center" justifyContent="space-between">
                                            <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                                                {review.userName || 'Anonymous User'}
                                            </Typography>
                                            <Typography variant="caption" color="text.secondary">
                                                {review.date}
                                            </Typography>
                                        </Box>
                                    }
                                    secondary={
                                        <>
                                            <Rating value={review.rating} readOnly size="small" sx={{ mb: 0.5 }} />
                                            <Typography component="span" variant="body2" color="text.primary" display="block">
                                                {review.comment}
                                            </Typography>
                                        </>
                                    }
                                />
                            </ListItem>
                            <Divider variant="fullWidth" component="li" sx={{ my: 2 }} />
                        </Box>
                    ))}
                </List>
            )}
        </Box>
    );
};

export default ReviewList;