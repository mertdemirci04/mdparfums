// src/components/ProfilePage.js
import React from 'react';
import { Container, Typography, Grid, Paper, List, ListItem, ListItemButton, ListItemIcon, ListItemText, Box } from '@mui/material';
import { Link, Outlet, useLocation } from 'react-router-dom';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import ListAltIcon from '@mui/icons-material/ListAlt';
import { useAuth } from './AuthContext'; 
import SettingsIcon from '@mui/icons-material/Settings';

// Menu items for the profile sidebar
const profileMenuItems = [
    { name: 'My Account Info', icon: AccountCircleIcon, path: '/profil' },
    { name: 'My Orders', icon: ListAltIcon, path: '/siparislerim' },
    { name: 'Settings', icon: SettingsIcon, path: '/profil/ayarlar' },
];

// Account Information Component (Dynamic)
const ProfileInfo = () => {
    const { user } = useAuth();
    
    // Placeholder logic if user data is missing
    const userName = user?.name || 'Guest User';
    const userEmail = user?.email || 'Information not found';

    return (
        <Box>
            <Typography variant="h5" gutterBottom sx={{ fontWeight: 600 }}>
                My Account Information
            </Typography>
            <Paper elevation={1} sx={{ p: 3, mt: 2 }}>
                <Typography variant="body1">
                    Full Name: {userName}
                </Typography>
                <Typography variant="body1">
                    Email: {userEmail}
                </Typography>
                {/* Informational note for user updates */}
                <Typography variant="body1" sx={{ mt: 1, color: 'text.secondary' }}>
                    *You can update your account information and password in the Settings section.
                </Typography>
            </Paper>
        </Box>
    );
};


const ProfilePage = () => {
    const location = useLocation();

    return (
        <Container maxWidth="lg" sx={{ mt: 4, mb: 8 }}>
            <Typography variant="h4" component="h1" gutterBottom color="primary" sx={{ mb: 4, fontWeight: 700 }}>
                My User Profile
            </Typography>
            
            <Grid container spacing={4}>
                
                {/* Left Sidebar / Navigation */}
                <Grid item xs={12} md={3}>
                    <Paper elevation={3} sx={{ p: 2 }}>
                        <List component="nav">
                            {profileMenuItems.map((item) => (
                                <ListItem key={item.path} disablePadding>
                                    <ListItemButton 
                                        component={Link} 
                                        to={item.path}
                                        selected={location.pathname === item.path}
                                        sx={{ 
                                            borderRadius: 1,
                                            '&.Mui-selected': {
                                                backgroundColor: 'primary.main',
                                                color: 'white',
                                                '& .MuiListItemIcon-root': { color: 'white' },
                                            },
                                            '&.Mui-selected:hover': {
                                                backgroundColor: 'primary.dark',
                                            }
                                        }}
                                    >
                                        <ListItemIcon>
                                            <item.icon />
                                        </ListItemIcon>
                                        <ListItemText primary={item.name} />
                                    </ListItemButton>
                                </ListItem>
                            ))}
                        </List>
                    </Paper>
                </Grid>

                {/* Right Content Area */}
                <Grid item xs={12} md={9}>
                    <Paper elevation={3} sx={{ p: { xs: 2, md: 4 } }}>
                        <Outlet /> 
                        {location.pathname === '/profil' && <ProfileInfo />} 
                    </Paper>
                </Grid>
            </Grid>
        </Container>
    );
};

export default ProfilePage;