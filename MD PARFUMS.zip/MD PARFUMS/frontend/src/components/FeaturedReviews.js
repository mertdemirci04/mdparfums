// src/components/FeaturedReviews.js
import React from 'react';
import { Container, Typography, Grid, Card, CardContent, Rating, Box, Avatar } from '@mui/material'; 
import FormatQuoteIcon from '@mui/icons-material/FormatQuote';

// STATIC REVIEWS
const staticReviews = [
    {
        id: 1,
        user: "Mert Demirci",
        rating: 5,
        comment: "It's a wonderful scent, very masculine, I definitely recommend it!",
        date: "6.12.2025"
    },
    {
        id: 2,
        user: "Ahmet K.",
        rating: 4.5,
        comment: "The niche collection far exceeded my expectations. The Aventus dupe, in particular, is fantastic.",
        date: "15.11.2025"
    },
    {
        id: 3,
        user: "Deniz Y.",
        rating: 5,
        comment: "The delivery was very fast, and the packaging was meticulous. Thank you for the gift note. They truly deliver quality.",
        date: "29.11.2025"
    },
    {
        id: 4,
        user: "Emre T.",
        rating: 4,
        comment: "The scent profile I got from the Designer series is very close to the original. The price is excellent, I definitely recommend it.",
        date: "05.12.2025"
    },
];

const FeaturedReviews = () => {
    return (
        <Box sx={{ py: 6, bgcolor: '#f7f7f7', mt: 5 }}> 
            <Container maxWidth="lg">
                <Typography 
                    variant="h4" 
                    component="h2" 
                    align="center" 
                    color="primary" 
                    gutterBottom 
                    sx={{ fontWeight: 700, mb: 4 }}
                >
                    What Our Customers Say?
                </Typography>

                {/* Grid container spacing*/}
                <Grid container spacing={4} justifyContent="center">
                    {staticReviews.map((review) => (
                        <Grid 
                            item 
                            xs={12} 
                            sm={6} 
                            md={4}
                            lg={3}
                            key={review.id}
                        > 
                            <Card sx={{ 
                                height: '100%', 
                                display: 'flex', 
                                flexDirection: 'column', 
                                p: 1, 
                                boxShadow: 3,
                                '&:hover': { boxShadow: 8 } 
                            }}>
                                <CardContent sx={{ flexGrow: 1 }}>
                                    <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 1 }}>
                                        <FormatQuoteIcon color="secondary" sx={{ fontSize: 32 }} />
                                        <Rating value={review.rating} readOnly precision={0.5} size="small" />
                                    </Box>
                                    
                                    <Typography variant="body1" sx={{ fontStyle: 'italic', mb: 2 }}>
                                        "{review.comment}"
                                    </Typography>
                                    
                                    <Box display="flex" alignItems="center" mt={3} sx={{ borderTop: '1px solid #eee', pt: 1 }}>
                                        <Avatar sx={{ bgcolor: 'primary.main', width: 40, height: 40, mr: 1 }}>
                                            {review.user.charAt(0)}
                                        </Avatar>
                                        <Box>
                                            <Typography variant="subtitle2" sx={{ fontWeight: 600 }}>
                                                {review.user}
                                            </Typography>
                                            <Typography variant="caption" color="text.secondary">
                                                {review.date}
                                            </Typography>
                                        </Box>
                                    </Box>
                                </CardContent>
                            </Card>
                        </Grid>
                    ))}
                </Grid>
            </Container>
        </Box>
    );
};

export default FeaturedReviews;