// src/components/CheckoutPage.js
import React, { useState } from 'react';
import { Container, Typography, Paper, Stepper, Step, StepLabel, Button, Box, Alert } from '@mui/material'; 
import { useNavigate } from 'react-router-dom';
import { useCart } from './CartContext'; 
import { useAuth } from './AuthContext'; 
import AddressForm from './AddressForm'; 
import PaymentForm from './PaymentForm'; 
import ReviewForm from './ReviewForm';   

// Checkout Steps
const steps = ['Delivery Address', 'Payment Information', 'Confirm Order'];

const initialFormData = {
    firstName: '',
    lastName: '',
    address1: '',
    city: '',
    zip: '',
    country: '',
    cardName: '',
    cardNumber: '',
    expDate: '',
    cvv: '',
};

const saveOrderToLocalStorage = (orderData) => {
    const orders = JSON.parse(localStorage.getItem('all_orders') || '[]');
    orders.push(orderData);
    localStorage.setItem('all_orders', JSON.stringify(orders));
};

const CheckoutPage = () => {
  const [activeStep, setActiveStep] = useState(0);
  const [formData, setFormData] = useState(initialFormData);
  const [placedOrderId, setPlacedOrderId] = useState(null); 
  
  const navigate = useNavigate();
  const { cartItems, cartTotals, confirmOrder } = useCart(); 
  const { user, isAuthenticated } = useAuth(); 
  
  const handleFormChange = (event) => {
    const { name, value } = event.target;
    setFormData(prev => ({
        ...prev,
        [name]: value,
    }));
  };

  const validateStep = (step) => {
      switch (step) {
          case 0:
              return formData.firstName && formData.lastName && formData.address1 && formData.city && formData.zip && formData.country;
          case 1:
              return formData.cardName && 
                     formData.cardNumber && formData.cardNumber.length >= 16 && 
                     formData.expDate && 
                     formData.cvv && formData.cvv.length >= 3;
          default:
              return true;
      }
  };

  if (cartItems.length === 0 && activeStep !== steps.length) {
      return (
          <Container maxWidth="md" sx={{ mt: 5, textAlign: 'center' }}>
              <Alert severity="warning" sx={{ mb: 3 }}>You must have items in your cart to proceed with the checkout process.</Alert>
              <Button variant="contained" color="primary" onClick={() => navigate('/parfum')}>
                  Start Shopping
              </Button>
          </Container>
      );
  }

  const handleNext = () => {
    if (!validateStep(activeStep)) {
        alert("Please fill in all required fields correctly to proceed.");
        return; 
    }
    setActiveStep(activeStep + 1);
  };

  const handleBack = () => {
    setActiveStep(activeStep - 1);
  };
  
  const handlePlaceOrder = () => {
      if (!isAuthenticated) {
          alert("Please log in to place an order.");
          navigate('/login');
          return;
      }
      
      const orderId = 'ORD-' + Date.now(); 
      setPlacedOrderId(orderId); 
      
      const shipping = cartTotals.total >= 1000 ? 0.00 : 25.00;
      
      const newOrder = {
          id: orderId,
          userId: user.id, 
          date: new Date().toLocaleDateString('en-US'),
          total: (cartTotals.total + shipping).toFixed(2),
          status: 'Processing', 
          items: cartItems.map(item => ({ name: item.name, quantity: item.quantity, price: item.price })),
          address: `${formData.address1}, ${formData.city}`,
      };
      
      // 1. Save order to local storage
      saveOrderToLocalStorage(newOrder); 
      
      confirmOrder(); 
      
      // 2. Move to Success screen (Step 2)
      setActiveStep(activeStep + 1);
  };
  
  function getStepContent(step) {
      switch (step) {
          case 0: return <AddressForm formData={formData} handleFormChange={handleFormChange} />;
          case 1: return <PaymentForm formData={formData} handleFormChange={handleFormChange} />;
          case 2: return <ReviewForm formData={formData} />; 
          default: throw new Error('Unknown Step');
      }
  }

  return (
    <Container maxWidth="md" sx={{ mt: 5, mb: 8 }}>
      <Paper elevation={3} sx={{ p: { xs: 2, md: 4 }, my: { xs: 3, md: 6 } }}>
        <Typography component="h1" variant="h4" align="center" sx={{ mb: 4, fontWeight: 600, color: 'primary.dark' }}>
          Checkout Process
        </Typography>
        
        <Stepper activeStep={activeStep} sx={{ pt: 3, pb: 5 }}>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
        
        {activeStep === steps.length ? (
          <Box sx={{ textAlign: 'center', py: 5 }}>
            <Alert severity="success" sx={{ mb: 2 }}>
              Your order has been successfully placed!
            </Alert>
            <Typography variant="subtitle1" sx={{ mb: 3 }}>
              Your order number is: <strong>#{placedOrderId}</strong>. Details have been sent to your email address.
            </Typography>
            <Button variant="contained" color="primary" onClick={() => navigate('/siparislerim')}>
              View My Orders
            </Button>
          </Box>
        ) : (
          <>
            {getStepContent(activeStep)}
            <Box sx={{ display: 'flex', justifyContent: 'flex-end', mt: 3 }}>
              {activeStep !== 0 && (
                <Button onClick={handleBack} sx={{ mr: 1 }}>Back</Button>
              )}
              
              {activeStep === steps.length - 1 ? (
                  <Button variant="contained" color="primary" onClick={handlePlaceOrder}>
                      Confirm Order
                  </Button>
              ) : (
                  <Button variant="contained" color="primary" onClick={handleNext}>Next</Button>
              )}
            </Box>
          </>
        )}
      </Paper>
    </Container>
  );
};

export default CheckoutPage;