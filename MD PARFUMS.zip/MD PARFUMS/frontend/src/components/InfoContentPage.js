// src/components/InfoContentPage.js
import React, { useEffect, useState } from 'react';
import { Container, Typography, Paper, Alert, Box, CircularProgress } from '@mui/material';
import { useLocation } from 'react-router-dom';
import { INFO_PAGES } from '../InfoData';

const InfoContentPage = () => {
    const location = useLocation()
    const [pageContent, setPageContent] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        setLoading(true);
        const path = location.pathname;
        const content = INFO_PAGES[path];

        if (content) {
            setPageContent(content);
        } else {
            setPageContent({ title: "Page Not Found", content: "The content you are looking for does not exist (404)." });
        }
        setLoading(false);
    }, [location.pathname]);

    if (loading) {
        return (
            <Container maxWidth="md" sx={{ mt: 5, textAlign: 'center' }}>
                <CircularProgress />
            </Container>
        );
    }

    const { title, content } = pageContent;

    return (
        <Container maxWidth="md" sx={{ mt: 5, mb: 8 }}>
            <Paper elevation={3} sx={{ p: { xs: 3, md: 5 } }}>
                <Typography 
                    component="h1" 
                    variant="h4" 
                    align="center" 
                    color="primary" 
                    sx={{ fontWeight: 700, mb: 4 }}
                >
                    {title}
                </Typography>
                
                {content.includes('404') ? (
                    <Alert severity="warning">{content}</Alert>
                ) : (
                    <Typography variant="body1" paragraph sx={{ whiteSpace: 'pre-line' }}>
                        {content}
                    </Typography>
                )}

                {location.pathname === '/iletisim' && (
                    <Box sx={{ mt: 4, pt: 2, borderTop: '1px solid #eee' }}>
                        <Typography variant="subtitle1" sx={{ fontWeight: 600 }}>
                            Address and Phone
                        </Typography>
                        <Typography variant="body2">
                            {INFO_PAGES['/iletisim'].content}
                        </Typography>
                    </Box>
                )}
            </Paper>
        </Container>
    );
};

export default InfoContentPage;
