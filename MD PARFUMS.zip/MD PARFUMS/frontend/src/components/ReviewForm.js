// src/components/ReviewForm.js
import React from 'react';
import { Typography, List, ListItem, ListItemText, Grid, Divider } from '@mui/material';
import { useCart } from './CartContext';

// Component receives data as props
const ReviewForm = ({ formData }) => {
  const { cartItems } = useCart();
  const subtotal = cartItems.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const shipping = subtotal >= 1000 ? 0.00 : 25.00;
  const total = subtotal + shipping;

  return (
    <>
      <Typography variant="h6" gutterBottom>
        Order Summary
      </Typography>
      
      {/* Product List */}
      <List disablePadding>
        {cartItems.map((product) => (
          <ListItem key={product.id} sx={{ py: 1, px: 0 }}>
            <ListItemText 
              primary={product.name} 
              secondary={`Brand: ${product.brand} | Qty: ${product.quantity}`} 
            />
            <Typography variant="body2">${(product.price * product.quantity).toFixed(2)}</Typography>
          </ListItem>
        ))}
        
        <Divider sx={{ my: 1 }} />
        
        {/* Price Details */}
        <ListItem sx={{ py: 1, px: 0 }}>
          <ListItemText primary="Subtotal" />
          <Typography variant="subtitle1">${subtotal.toFixed(2)}</Typography>
        </ListItem>
        <ListItem sx={{ py: 1, px: 0 }}>
          <ListItemText primary="Shipping Fee" />
          <Typography variant="subtitle1">{shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`}</Typography>
        </ListItem>
        <ListItem sx={{ py: 1, px: 0 }}>
          <ListItemText primary="Total" primaryTypographyProps={{ fontWeight: 700 }} />
          <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>${total.toFixed(2)}</Typography>
        </ListItem>
      </List>
      
      <Grid container spacing={2} sx={{ mt: 3 }}>
          {/* Shipping Address Details */}
          <Grid item xs={12} sm={6}>
              <Typography variant="h6" gutterBottom>Shipping Address</Typography>
              <Typography gutterBottom sx={{ fontWeight: 600 }}>{formData.firstName} {formData.lastName}</Typography>
              <Typography>{formData.address1}</Typography>
              <Typography>{formData.zip}, {formData.city}, {formData.country}</Typography>
          </Grid>
          
          {/* Payment Details */}
          <Grid item xs={12} sm={6}>
              <Typography variant="h6" gutterBottom>Payment Method</Typography>
              <Typography gutterBottom sx={{ fontWeight: 600 }}>{formData.cardName}</Typography>
              <Typography>Card No: **** **** **** {formData.cardNumber.slice(-4)}</Typography>
              <Typography>Expiry Date: {formData.expDate}</Typography>
          </Grid>
      </Grid>
    </>
  );
};

export default ReviewForm;