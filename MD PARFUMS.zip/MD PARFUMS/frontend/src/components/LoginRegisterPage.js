// src/components/LoginRegisterPage.js
import React, { useState } from 'react';
import { Container, Paper, Typography, Box, Tabs, Tab } from '@mui/material';
import LoginForm from './LoginForm';
import RegisterForm from './RegisterForm';

function TabPanel(props) {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`tabpanel-${index}`}
      aria-labelledby={`tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
}

const LoginRegisterPage = () => {
  const [value, setValue] = useState(0); // 0: Login, 1: Register
  
  const handleChange = (event, newValue) => {
    setValue(newValue);
  };

  return (
    <Container maxWidth="sm" sx={{ mt: 5, mb: 8 }}>
      <Paper elevation={4} sx={{ p: 0 }}>
        <Typography 
            component="h1" 
            variant="h4" 
            align="center" 
            sx={{ pt: 4, fontWeight: 600, color: 'primary.dark' }}
        >
            My Account
        </Typography>
        
        {/* Tabs */}
        <Box sx={{ borderBottom: 1, borderColor: 'divider', mt: 2 }}>
          <Tabs 
              value={value} 
              onChange={handleChange} 
              aria-label="Login and Register Tabs"
              centered
          >
            <Tab label="Login" id="tab-0" aria-controls="tabpanel-0" />
            <Tab label="Register" id="tab-1" aria-controls="tabpanel-1" />
          </Tabs>
        </Box>
        
        {/* Form Contents */}
        <TabPanel value={value} index={0}>
          <LoginForm />
        </TabPanel>
        <TabPanel value={value} index={1}>
          <RegisterForm />
        </TabPanel>
        
      </Paper>
    </Container>
  );
};

export default LoginRegisterPage;
