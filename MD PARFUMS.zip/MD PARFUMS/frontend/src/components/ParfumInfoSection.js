// src/components/ParfumInfoSection.js
import React from 'react';
import { Container, Typography, Box, Paper, Divider } from '@mui/material';
import WarningAmberIcon from '@mui/icons-material/WarningAmber';


const ParfumInfoSection = () => {
    return (
        <Container maxWidth="1g" sx={{ mt: 8, mb: 8 }}>
            
            {/* Title Area */}
            <Typography variant="h3" component="h1" gutterBottom align="center" color="primary" sx={{ fontWeight: 700, mb: 4 }}>
                Open Perfume Information Center
            </Typography>

            {/* Warning / Summary Box */}
            <Paper elevation={4} sx={{ p: 3, mb: 5, bgcolor: 'secondary.light', borderRadius: 2 }}>
                <Box display="flex" alignItems="center" mb={1}>
                    <WarningAmberIcon color="warning" sx={{ mr: 1 }} />
                    <Typography variant="h6" color="text.primary">
                        What You Need to Know About Perfume Performance
                    </Typography>
                </Box>
                <Typography variant="body1" sx={{ color: 'text.secondary' }}>
                    Open perfume models have become popular thanks to their long-lasting performance and budget-friendly prices. The most frequently asked questions are about longevity, projection, and similarity to the original fragrance.
                </Typography>
            </Paper>

            <Box sx={{ mt: 4 }}>
                
                {/* 1. Perfume Composition and Longevity Differences */}
                <Typography variant="h5" component="h2" color="primary" sx={{ mb: 1, mt: 3, fontWeight: 600 }}>
                    Perfume Composition and Longevity Differences
                </Typography>
                <Divider sx={{ mb: 2 }} />
                <Typography variant="body1" paragraph>
                    Perfumes range from intense and heavy scents to light and fresh notes. Dense ingredients such as tobacco or vanilla provide longer longevity, while lighter notes like apple and chamomile may fade more quickly. These characteristics apply to both open perfumes and original branded products, and managing expectations correctly is important.
                </Typography>

                {/* 2. Effect of Seasons on Perfume Performance */}
                <Typography variant="h5" component="h2" color="primary" sx={{ mb: 1, mt: 3, fontWeight: 600 }}>
                    The Effect of Seasons and Environment on Performance
                </Typography>
                <Divider sx={{ mb: 2 }} />
                <Typography variant="body1" paragraph>
                    Environmental factors—especially seasons and meteorological conditions (temperature, humidity)—significantly affect perfume performance. As temperatures rise in summer, perfume molecules evaporate more quickly (projection increases, longevity decreases). In winter, evaporation slows down, allowing the fragrance to last longer. Considering these conditions is beneficial when choosing a dupe perfume.
                </Typography>

                {/* 3. Refill Perfumes: Affordable and Quality Alternatives */}
                <Typography variant="h5" component="h2" color="primary" sx={{ mb: 1, mt: 3, fontWeight: 600 }}>
                    Refill Perfumes and Production Quality
                </Typography>
                <Divider sx={{ mb: 2 }} />
                <Typography variant="body1" paragraph>
                    Refill perfumes offer an affordable alternative with compositions similar to original products. However, not only price but also product quality and details such as the spray mechanism affect the overall experience. Our products are manufactured by expert chemists with Ministry of Health notification. The essence concentration alone is not a measure of quality; the key factor is the quality of the raw materials used.
                </Typography>
                <Typography variant="body1" paragraph>
                    Our company develops special formulas for each model to deliver high-quality and accessible products. Personal preferences and skin chemistry also play a critical role in perfume selection; therefore, testing scent profiles that suit your skin is a sensible approach.
                </Typography>

            </Box>
        </Container>
    );
};

export default ParfumInfoSection;
