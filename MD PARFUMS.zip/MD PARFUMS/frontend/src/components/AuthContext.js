// src/components/AuthContext.js
import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

// Mock Backend Service: Stores users in local storage.
const mockApi = {
    getUsers: () => {
        const storedUsers = localStorage.getItem('mock_users');
        return storedUsers ? JSON.parse(storedUsers) : [];
    },
    updateUsers: (updatedUsers) => {
        localStorage.setItem('mock_users', JSON.stringify(updatedUsers));
    },
    login: (email, password) => {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                const users = mockApi.getUsers();
                const user = users.find(u => u.email === email && u.password === password);

                const TEST_USER_EMAIL = "test@mail.com";
                const testUserMatch = email === TEST_USER_EMAIL && password === "123456";

                if (user || testUserMatch) {
                    const finalUser = user ? { id: user.id, name: user.name, email: user.email } :
                                             { id: 1, name: "Test Kullanıcısı", email: TEST_USER_EMAIL };
                    resolve({
                        success: true,
                        token: "mock-token-123",
                        user: finalUser
                    });
                } else {
                    reject({ success: false, message: "Invalid email or password." });
                }
            }, 800);
        });
    },
    register: (name, email, password) => {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                const users = mockApi.getUsers();
                if (users.some(u => u.email === email)) {
                    return reject({ success: false, message: "This email address is already registered." });
                }
                const newUser = {
                    id: Date.now(),
                    name,
                    email,
                    password
                };
                users.push(newUser);
                mockApi.updateUsers(users);
                resolve({
                    success: true,
                    token: "mock-token-456",
                    user: { id: newUser.id, name: newUser.name, email: newUser.email }
                });
            }, 800);
        });
    },
    updatePassword: (userId, oldPassword, newPassword) => {
        return new Promise((resolve, reject) => {
            setTimeout(() => {
                const users = mockApi.getUsers();
                const userIndex = users.findIndex(u => u.id === userId);

                if (userIndex === -1) {
                    return reject({ message: "Kullanıcı bulunamadı." });
                }
                if (users[userIndex].password !== oldPassword) {
                    return reject({ message: "Mevcut şifreniz yanlış." });
                }
                users[userIndex].password = newPassword;
                mockApi.updateUsers(users);
                resolve({ success: true });
            }, 1000);
        });
    }
};

// useAuth hook
export const useAuth = () => {
    const context = useContext(AuthContext);
    if (!context) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};

export const AuthProvider = ({ children }) => {
    const [user, setUser] = useState(null);
    const [loading, setLoading] = useState(true);

    // User information is initially retrieved from localStorage.
    useEffect(() => {
        try {
            const storedUser = localStorage.getItem('user');
            if (storedUser) {
                setUser(JSON.parse(storedUser));
            }
        } finally {
            setLoading(false);
        }
    }, []);

    const login = async (email, password) => {
        try {
            const response = await mockApi.login(email, password);
            localStorage.setItem('user', JSON.stringify(response.user));
            setUser(response.user);
            return response.user;
        } catch (err) {
            if (err && err.message) throw err;
            throw { message: 'An error occurred during login.' };
        }
    };

    const register = async (name, email, password) => {
        try {
            const response = await mockApi.register(name, email, password);
            localStorage.setItem('user', JSON.stringify(response.user));
            setUser(response.user);
            return response.user;
        } catch (err) {
            if (err && err.message) throw err;
            throw { message: 'An error occurred during registration.' };
        }
    };

    const logout = () => {
        localStorage.removeItem('user');
        setUser(null);
    };

    const updatePassword = async (userId, oldPassword, newPassword) => {
        try {
            await mockApi.updatePassword(userId, oldPassword, newPassword);
            return { success: true };
        } catch (err) {
            if (err && err.message) throw err;
            throw { message: 'An error occurred while updating the password.' };
        }
    };

    const value = {
        user,
        isAuthenticated: !!user,
        login,
        register,
        logout,
        updatePassword,
        loading
    };

    return (
        <AuthContext.Provider value={value}>
            {children}
        </AuthContext.Provider>
    );
};
