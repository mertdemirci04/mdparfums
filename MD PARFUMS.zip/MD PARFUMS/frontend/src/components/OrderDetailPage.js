// src/components/OrderDetailPage.js
import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { Container, Typography, Paper, Grid, Box, List, ListItem, ListItemText, Divider, Alert, Button } from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

const OrderDetailPage = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const [order, setOrder] = useState(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        const fetchOrder = () => {
            const allOrders = JSON.parse(localStorage.getItem('all_orders') || '[]');
            const foundOrder = allOrders.find(o => o.id === id);
            setOrder(foundOrder);
            setLoading(false);
        };
        
        fetchOrder();
    }, [id]);

    if (loading) {
        return (
            <Container maxWidth="md" sx={{ mt: 5 }}>
                <Typography>Loading Order Details...</Typography>
            </Container>
        );
    }

    if (!order) {
        return (
            <Container maxWidth="md" sx={{ mt: 5 }}>
                <Alert severity="error">
                    Order details could not be found. Please check your order number.
                </Alert>
                <Button
                    sx={{ mt: 2 }}
                    startIcon={<ArrowBackIcon />}
                    onClick={() => navigate('/my-orders')}
                >
                    Back to My Orders
                </Button>
            </Container>
        );
    }

    return (
        <Container maxWidth="lg" sx={{ mt: 4, mb: 8 }}>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={4}>
                <Typography variant="h4" component="h1" sx={{ fontWeight: 700 }}>
                    Order Details - #{order.id}
                </Typography>
                <Button
                    startIcon={<ArrowBackIcon />}
                    onClick={() => navigate('/siparislerim')}
                >
                    Back to All Orders
                </Button>
            </Box>

            <Grid container spacing={4}>
                {/* Left Section: Order and Address Information */}
                <Grid item xs={12} md={5}>
                    <Paper elevation={3} sx={{ p: 3 }}>
                        <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                            General Information
                        </Typography>
                        <Divider sx={{ mb: 2 }} />
                        <ListItemText
                            primary={<Typography sx={{ fontWeight: 600 }}>Status</Typography>}
                            secondary={order.status}
                        />
                        <ListItemText
                            primary={<Typography sx={{ fontWeight: 600 }}>Order Date</Typography>}
                            secondary={order.date}
                        />
                        <ListItemText
                            primary={<Typography sx={{ fontWeight: 600 }}>Total Amount</Typography>}
                            secondary={`${order.total} TL`}
                        />

                        <Divider sx={{ my: 3 }} />

                        <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                            Shipping Address
                        </Typography>
                        <ListItemText secondary={order.address} />
                    </Paper>
                </Grid>

                {/* Right Section: Product Details */}
                <Grid item xs={12} md={7}>
                    <Paper elevation={3} sx={{ p: 3 }}>
                        <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
                            Ordered Products
                        </Typography>
                        <List>
                            {order.items.map((item, index) => (
                                <Box key={index}>
                                    <ListItem disablePadding sx={{ py: 1 }}>
                                        <ListItemText
                                            primary={item.name}
                                            secondary={`${item.quantity} pcs x ${item.price.toFixed(2)} TL`}
                                        />
                                        <Typography variant="body1" sx={{ fontWeight: 600 }}>
                                            {(item.quantity * item.price).toFixed(2)} TL
                                        </Typography>
                                    </ListItem>
                                    <Divider component="li" />
                                </Box>
                            ))}
                        </List>
                    </Paper>
                </Grid>
            </Grid>
        </Container>
    );
};

export default OrderDetailPage;
