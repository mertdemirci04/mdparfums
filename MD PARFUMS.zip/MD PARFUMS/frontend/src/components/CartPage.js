// src/components/CartPage.js
import React from 'react';
import { useNavigate, Link as RouterLink } from 'react-router-dom';
import { 
    Container, Typography, Alert, Grid, Button, Box, IconButton, Divider, 
    CardMedia, InputBase, Paper, TextField 
} from '@mui/material';
import RemoveIcon from '@mui/icons-material/Remove';
import AddIcon from '@mui/icons-material/Add';
import CloseIcon from '@mui/icons-material/Close'; 
import CreditCardIcon from '@mui/icons-material/CreditCard';
import LocalOfferIcon from '@mui/icons-material/LocalOffer';
import ShoppingBagOutlinedIcon from '@mui/icons-material/ShoppingBagOutlined';
import { useCart } from './CartContext'; 

const CompactCartItem = ({ item, handleUpdateQuantity, handleRemoveItem }) => (
    <Box sx={{ 
        display: 'flex', 
        borderBottom: '1px solid #eee', 
        py: 2,
        alignItems: 'flex-start',
        position: 'relative',
        pr: 4 
    }}>
        
        <IconButton 
            size="small" 
            color="error"
            sx={{ position: 'absolute', top: 8, right: 0, zIndex: 5 }} 
            onClick={() => handleRemoveItem(item.id)}
        >
            <CloseIcon fontSize="small" /> 
        </IconButton>

        <CardMedia
            component={RouterLink}
            to={`/product/${item.originalId || item.id}`} 
            image={item.imageUrl || '/placeholder.jpg'}
            sx={{ width: 60, height: 60, minWidth: 60, objectFit: 'cover', mr: 2, cursor: 'pointer', borderRadius: 1 }}
        />

        <Box sx={{ flexGrow: 1, pr: 2 }}>
            <Typography variant="body1" sx={{ fontWeight: 600 }}>
                {item.name}
            </Typography>
            <Typography variant="caption" color="text.secondary">
                Brand: {item.brand} | Volume: {item.volume} ml
            </Typography>
        </Box>

        <Box sx={{ 
            display: 'flex',
            flexDirection: 'column',
            alignItems: 'flex-end',
            minWidth: 120, 
            textAlign: 'right',
            ml: 1,
            pt: 0.5 
        }}>
            <Typography variant="subtitle1" color="primary.dark" sx={{ fontWeight: 700, mb: 0.5 }}>
                {(item.price * item.quantity).toFixed(2)} TL
            </Typography>

            <Box display="flex" alignItems="center" justifyContent="flex-end" border={1} borderColor="grey.300" borderRadius={0.5}>
                <IconButton size="small" onClick={() => handleUpdateQuantity(item.id, -1)} disabled={item.quantity <= 1}>
                    <RemoveIcon fontSize="inherit" />
                </IconButton>
                <InputBase
                    value={item.quantity}
                    readOnly
                    sx={{ width: 20, textAlign: 'center', fontSize: '0.8rem' }}
                />
                <IconButton size="small" onClick={() => handleUpdateQuantity(item.id, 1)}>
                    <AddIcon fontSize="inherit" />
                </IconButton>
            </Box>
        </Box>
    </Box>
);


// -------------------------------------------------------------
// CART PAGE
// -------------------------------------------------------------
const CartPage = () => {
    const navigate = useNavigate();
    const { cartItems, cartTotals, updateQuantity, removeFromCart } = useCart();
    
    const shipping = cartTotals.total >= 1000 ? 0.00 : 25.00;
    const finalTotal = cartTotals.total + shipping;

    const totalQuantity = cartItems.reduce((count, item) => count + item.quantity, 0);
    const neededForNextFree = 7 - (totalQuantity % 7 === 0 ? 7 : totalQuantity % 7);
    const campaignActive = totalQuantity >= 7;


    const handleUpdateQuantity = (id, amount) => {
        const item = cartItems.find(i => i.id === id);
        if (item) {
            updateQuantity(id, item.quantity + amount);
        }
    };

    const handleRemoveItem = (id) => {
        removeFromCart(id);
    };


    if (cartItems.length === 0) {
        return (
            <Container maxWidth="md" sx={{ mt: 5, mb: 8, textAlign: 'center' }}>
                <Alert severity="info" icon={<ShoppingBagOutlinedIcon />} sx={{ mb: 3 }}>
                    Your cart is empty yet.
                </Alert>
                <Button variant="contained" component={RouterLink} to="/parfum">
                    Start Shopping
                </Button>
            </Container>
        );
    }

    return (
        <Container maxWidth="lg" sx={{ mt: 4, mb: 8 }}>
            
            <Typography variant="h4" component="h1" sx={{ fontWeight: 600, mb: 4, color: 'primary.dark' }}>
                My Cart ({totalQuantity} Product)
            </Typography>

            <Grid container spacing={4}>
                
                <Grid item xs={12} md={7}>
                    
                    <Alert 
                        severity={campaignActive ? "success" : "warning"} 
                        sx={{ mb: 3, fontWeight: 500 }}
                    >
                        {campaignActive ? (
                            <Box>
                                Congratulations! The **Buy 6 Get 1 Free** promotion has been applied.
                                <Box component="span" sx={{ ml: 1, fontWeight: 700 }}>
                                    (Free Product: {cartTotals.freeItemName || "Cheapest Product"})
                                </Box>
                            </Box>
                        ) : (
                            <Box>
                                For the Buy 6 Get 1 Free campaign <Box component="span" sx={{ fontWeight: 700 }}>{neededForNextFree} procut</Box> add more!
                            </Box>
                        )}
                    </Alert>


                    <Paper elevation={1} sx={{ p: 2 }}>
                        {cartItems.map((item) => (
                            <CompactCartItem 
                                key={item.id}
                                item={item}
                                handleUpdateQuantity={handleUpdateQuantity}
                                handleRemoveItem={handleRemoveItem}
                            />
                        ))}
                    </Paper>
                    <Box sx={{ mt: 3, textAlign: 'left' }}>
                         <Button component={RouterLink} to="/parfum" variant="outlined" color="primary">
                            Continue Shopping
                        </Button>
                    </Box>
                </Grid>

                <Grid item xs={12} md={5}>
                    <Box sx={{ position: 'sticky', top: 20 }}>
                        
                        <Paper elevation={1} sx={{ p: 3, bgcolor: '#f7f7f7', mb: 3 }}>
                            <Typography variant="h6" gutterBottom sx={{ fontWeight: 700, mb: 2 }}>
                                Order Summary
                            </Typography>
                            
                            <Box display="flex" justifyContent="space-between" my={1}>
                                <Typography variant="body1">Subtotal of Orders</Typography>
                                <Typography variant="body1">{cartTotals.subtotal.toFixed(2)} TL</Typography>
                            </Box>
                            
                            {cartTotals.discount > 0 && (
                                <Box display="flex" justifyContent="space-between" my={1}>
                                    <Typography variant="body1" color="success.main" sx={{ fontWeight: 600 }}>
                                        Buy 6 Get 1 Free Campaign:
                                    </Typography>
                                    <Typography variant="body1" color="success.main" sx={{ fontWeight: 600 }}>
                                        -{cartTotals.discount.toFixed(2)} TL
                                    </Typography>
                                </Box>
                            )}
                            
                            <Box display="flex" justifyContent="space-between" my={1}>
                                <Typography variant="body1">Shipping Fee:</Typography>
                                <Typography variant="body1" sx={{ color: shipping === 0 ? 'green' : 'inherit', fontWeight: 600 }}>
                                    {shipping === 0 ? 'FREE' : `${shipping.toFixed(2)} TL`}
                                </Typography>
                            </Box>
                            
                            <Divider sx={{ my: 2 }} />

                            <Box display="flex" justifyContent="space-between" mb={3}>
                                <Typography variant="h5" sx={{ fontWeight: 700, color: 'primary.dark' }}>Total amount to be paid:</Typography>
                                <Typography variant="h5" color="error.main" sx={{ fontWeight: 700 }}>{finalTotal.toFixed(2)} TL</Typography>
                            </Box>

                            <Button
                                variant="contained"
                                color="primary"
                                fullWidth
                                size="large"
                                endIcon={<CreditCardIcon />}
                                onClick={() => navigate('/odeme')} 
                                sx={{ py: 1.5 }}
                            >
                             
                            Continue with Payment Process
                            </Button>
                        </Paper>
                        
                        {/* Coupon */}
                        <Paper elevation={1} sx={{ p: 3 }}>
                            <Typography variant="h6" gutterBottom sx={{ fontWeight: 700, mb: 2 }}>
                                <LocalOfferIcon sx={{ mr: 1, verticalAlign: 'middle' }} /> Enter Coupon Code
                            </Typography>
                            <Box display="flex" gap={1}>
                                <TextField
                                    size="small"
                                    placeholder="Coupon Code"
                                    fullWidth
                                />
                                <Button variant="contained" color="secondary" sx={{ minWidth: 100 }}>
                                    Apply
                                </Button>
                            </Box>
                        </Paper>
                        
                    </Box>
                </Grid>
            </Grid>
        </Container>
    );
};

export default CartPage;