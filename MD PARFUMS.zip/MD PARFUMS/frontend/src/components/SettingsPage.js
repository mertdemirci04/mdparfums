// src/components/SettingsPage.js
import React, { useState } from 'react';
import { Box, Typography, TextField, Button, Paper, Divider, Alert, CircularProgress, Container } from '@mui/material';
import { useAuth } from './AuthContext';

// This page is where the user updates their profile information and changes their password.
const SettingsPage = () => {
    const { user, logout, updatePassword } = useAuth(); 
    
    // Form States
    const [currentPassword, setCurrentPassword] = useState('');
    const [newPassword, setNewPassword] = useState('');
    const [confirmPassword, setConfirmPassword] = useState('');
    
    // Name state (Initially the current user's name)
    const [newName, setNewName] = useState(user?.name || '');
    
    const [loading, setLoading] = useState(false);
    const [message, setMessage] = useState({ text: '', severity: '' });

    // Password Change Handler
    const handlePasswordChange = async (e) => { 
        e.preventDefault();
        setMessage({ text: '', severity: '' });

        if (!currentPassword || !newPassword || !confirmPassword) {
            setMessage({ text: 'Please fill in all fields.', severity: 'error' });
            return;
        }

        if (newPassword !== confirmPassword) {
            setMessage({ text: 'New passwords do not match.', severity: 'error' });
            return;
        }
        if (newPassword.length < 6) {
             setMessage({ text: 'Password must be at least 6 characters long.', severity: 'error' });
            return;
        }

        setLoading(true);

        try {
            await updatePassword(user.id, currentPassword, newPassword);
            
            setLoading(false);
            setMessage({ text: 'Your password has been successfully updated. You can now log in with your new password.', severity: 'success' });
            
            // Clear the form
            setCurrentPassword('');
            setNewPassword('');
            setConfirmPassword('');
            
        } catch (error) {
            setLoading(false);
            // Show the error message coming from AuthContext
            setMessage({ text: error.message || 'Password update failed.', severity: 'error' });
        }
    };

    // Profile Update Handler (Name/Email)
    const handleProfileUpdate = (e) => {
        e.preventDefault();
        setMessage({ text: '', severity: '' });

        if (newName.trim() === user?.name) {
            setMessage({ text: 'The new name is the same as your current name.', severity: 'warning' });
            return;
        }

        setLoading(true);

        setTimeout(() => {
            if (user) user.name = newName; 

            setLoading(false);
            setMessage({ text: 'Your account information has been updated.', severity: 'success' });
        }, 1500);
    };

    return (
        <Container maxWidth="md" sx={{ mt: 4, mb: 8 }}>
            <Typography variant="h4" component="h1" gutterBottom color="primary" sx={{ mb: 4, fontWeight: 700 }}>
                Settings
            </Typography>

            <Paper elevation={3} sx={{ p: { xs: 2, md: 4 } }}>
                
                {message.text && <Alert severity={message.severity} sx={{ mb: 3 }}>{message.text}</Alert>}

                {/* 1. Profile Information Update Form */}
                <Box component="form" onSubmit={handleProfileUpdate}>
                    <Typography variant="h6" sx={{ mb: 2 }}>
                        Profile Information
                    </Typography>
                    <Box sx={{ display: 'grid', gap: 2 }}>
                        <TextField
                            label="Full Name"
                            value={newName}
                            onChange={(e) => setNewName(e.target.value)}
                            fullWidth
                        />
                        <TextField
                            label="Email Address"
                            value={user?.email || 'Loading...'}
                            disabled 
                            fullWidth
                        />
                        <Button 
                            type="submit" 
                            variant="contained" 
                            color="primary" 
                            disabled={loading || newName.trim() === user?.name}
                        >
                            {loading ? <CircularProgress size={24} color="inherit" /> : 'Update Profile'}
                        </Button>
                    </Box>
                </Box>

                <Divider sx={{ my: 4 }} />

                {/* 2. Password Change Form */}
                <Box component="form" onSubmit={handlePasswordChange}>
                    <Typography variant="h6" sx={{ mb: 2 }}>
                        Change Password
                    </Typography>
                    <Box sx={{ display: 'grid', gap: 2 }}>
                        <TextField
                            required
                            label="Current Password"
                            type="password"
                            value={currentPassword}
                            onChange={(e) => setCurrentPassword(e.target.value)}
                            fullWidth
                        />
                        <TextField
                            required
                            label="New Password"
                            type="password"
                            value={newPassword}
                            onChange={(e) => setNewPassword(e.target.value)}
                            fullWidth
                        />
                        <TextField
                            required
                            label="Confirm New Password"
                            type="password"
                            value={confirmPassword}
                            onChange={(e) => setConfirmPassword(e.target.value)}
                            fullWidth
                        />
                        <Button 
                            type="submit" 
                            variant="contained" 
                            color="secondary" 
                            disabled={loading}
                            sx={{ mt: 1 }}
                        >
                            {loading ? <CircularProgress size={24} color="inherit" /> : 'Change Password'}
                        </Button>
                    </Box>
                </Box>
            </Paper>

            <Box sx={{ mt: 4, textAlign: 'center' }}>
                 <Button onClick={logout} variant="text" color="error">
                    Secure Logout
                </Button>
            </Box>
        </Container>
    );
};

export default SettingsPage;