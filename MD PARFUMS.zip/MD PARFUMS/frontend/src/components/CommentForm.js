// src/components/CommentForm.js
import React, { useState } from 'react';
import { Box, TextField, Button, Typography, Rating, Alert, Paper } from '@mui/material';
import SendIcon from '@mui/icons-material/Send';
import { useAuth } from './AuthContext';

const CommentForm = ({ productId, addReview
 }) => {
    const { isAuthenticated, user } = useAuth();
    const [rating, setRating] = useState(0);
    const [comment, setComment] = useState('');
    const [isSubmitting, setIsSubmitting] = useState(false);

    const handleSubmit = (e) => {
        e.preventDefault();
        if (comment.trim().length < 5 || rating === 0) {
            alert("Please leave a review and rating.");
            return;
        }

        setIsSubmitting(true);
        
        
        setTimeout(() => {
            const newComment = {
                id: Date.now(), // Mock ID
                userId: user.id,
                userName: user.name,
                rating: rating,
                comment: comment,
                date: new Date().toLocaleDateString('tr-TR'),
            };
            
            addReview(newComment);
            
            setRating(0);
            setComment('');
            setIsSubmitting(false);
            
        }, 1000);
    };

    if (!isAuthenticated) {
        return (
            <Alert severity="info" sx={{ mt: 3 }}>
                Please log in to leave a comment.
            </Alert>
        );
    }
    
    return (
        <Paper component="form" onSubmit={handleSubmit} sx={{ p: 3, mt: 3, mb: 3 }}>
            <Typography variant="h6" gutterBottom>
                Add Your Comment
            </Typography>
            
            <Box display="flex" alignItems="center" mb={2}>
                <Typography component="legend" sx={{ mr: 1 }}>Your Score:</Typography>
                <Rating
                    name="product-rating"
                    value={rating}
                    onChange={(event, newValue) => { setRating(newValue); }}
                    precision={1}
                    size="large"
                />
            </Box>
            
            <TextField
                label="Your comment"
                multiline
                rows={4}
                fullWidth
                value={comment}
                onChange={(e) => setComment(e.target.value)}
                required
                sx={{ mb: 2 }}
            />
            
            <Button
                type="submit"
                variant="contained"
                color="primary"
                endIcon={<SendIcon />}
                disabled={isSubmitting}
            >
                {isSubmitting ? 'Sending...' : 'Send Comment'}
            </Button>
        </Paper>
    );
};

export default CommentForm;