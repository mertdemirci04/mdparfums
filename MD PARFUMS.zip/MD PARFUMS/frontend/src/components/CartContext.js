// src/components/CartContext.js
import React, { createContext, useContext, useState, useEffect } from 'react';
import { Snackbar, Alert } from '@mui/material';

const CartContext = createContext();

export const useCart = () => {
    const context = useContext(CartContext);
    if (!context) {
        throw new Error('useCart must be used within a CartProvider');
    }
    return context;
};

const initialCartTotals = {
    subtotal: 0,
    discount: 0,
    total: 0,
    freeItemName: null,
};

export const CartProvider = ({ children }) => {
    const [cartItems, setCartItems] = useState([]);
    const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
    const [cartTotals, setCartTotals] = useState(initialCartTotals);

    // Load from Local Storage on mount
    useEffect(() => {
        const storedCart = localStorage.getItem('cartItems');
        if (storedCart) {
            setCartItems(JSON.parse(storedCart));
        }
    }, []);

    // Sync with Local Storage and calculate totals whenever cart changes
    useEffect(() => {
        localStorage.setItem('cartItems', JSON.stringify(cartItems));
        calculateCartTotals(cartItems);
    }, [cartItems]);

    // Snackbar (Global Notifications) functions
    const showSnackbar = ({ message, severity = 'success' }) => {
        setSnackbar({ open: true, message, severity });
    };

    const closeSnackbar = () => {
        setSnackbar(prev => ({ ...prev, open: false }));
    };

    // Promotion Logic: Buy 6 Get 1 Free
    const calculateCartTotals = (items) => {
        let subtotal = 0;
        let totalQuantity = 0;
        
        items.forEach(item => {
            subtotal += item.price * item.quantity;
            totalQuantity += item.quantity;
        });

        let discount = 0;
        let freeItemName = null;

        // If total items are 7 or more, the campaign is active (6+1)
        if (totalQuantity >= 7) {
            const allIndividualItems = [];
            items.forEach(item => {
                for (let i = 0; i < item.quantity; i++) {
                    allIndividualItems.push({ 
                        price: item.price, 
                        name: item.name 
                    });
                }
            });

            // Sort by price (ascending) to find the cheapest item
            allIndividualItems.sort((a, b) => a.price - b.price);
            
            // Number of free items (1 for every 7 items)
            const freeCount = Math.floor(totalQuantity / 7);

            for (let i = 0; i < freeCount; i++) {
                if (allIndividualItems.length > i) {
                    discount += allIndividualItems[i].price;
                    freeItemName = allIndividualItems[i].name; 
                }
            }
        }
        
        setCartTotals({
            subtotal: subtotal,
            discount: discount,
            total: subtotal - discount,
            freeItemName: freeItemName,
        });
    };

    const addToCart = (item) => {
        setCartItems(prevItems => {
            const existingItem = prevItems.find(i => i.id === item.id);
            if (existingItem) {
                return prevItems.map(i =>
                    i.id === item.id ? { ...i, quantity: i.quantity + (item.quantity || 1) } : i
                );
            } else {
                return [...prevItems, { ...item, quantity: item.quantity || 1 }];
            }
        });
        showSnackbar({ message: `${item.name} added to cart.`, severity: 'success' });
    };

    const updateQuantity = (id, newQuantity) => {
        setCartItems(prevItems => {
            if (newQuantity <= 0) {
                return prevItems.filter(i => i.id !== id);
            }
            return prevItems.map(i =>
                i.id === id ? { ...i, quantity: newQuantity } : i
            );
        });
    };

    const removeFromCart = (id) => {
        setCartItems(prevItems => prevItems.filter(i => i.id !== id));
        showSnackbar({ message: 'Product removed from cart.', severity: 'info' });
    };

    // Confirm Order and Clear Cart
    const confirmOrder = () => {
        if (cartItems.length === 0) {
            showSnackbar({ message: 'Your cart is empty!', severity: 'error' });
            return;
        }

        // Clear cart state
        setCartItems([]);
        localStorage.removeItem('cartItems');
        
        // Show success notification
        showSnackbar({ 
            message: 'Your order has been received! Thank you for choosing MD Parfums.', 
            severity: 'success' 
        });
    };

    const value = {
        cartItems,
        snackbar,
        cartTotals,
        addToCart,
        updateQuantity,
        removeFromCart,
        confirmOrder,
        closeSnackbar,
        showSnackbar, 
    };

    return (
        <CartContext.Provider value={value}>
            {children}
            <Snackbar
                open={snackbar.open}
                autoHideDuration={4000}
                onClose={closeSnackbar}
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
            >
                <Alert onClose={closeSnackbar} severity={snackbar.severity} sx={{ width: '100%' }}>
                    {snackbar.message}
                </Alert>
            </Snackbar>
        </CartContext.Provider>
    );
};