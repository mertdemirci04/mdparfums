// src/components/AddressForm.js
import React from 'react';
import { Grid, Typography, TextField } from '@mui/material';

const AddressForm = ({ formData, handleFormChange }) => {
  return (
    <>
      <Typography variant="h6" gutterBottom>
        Delivery Address
      </Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} sm={6}>
          <TextField 
            required 
            id="firstName" 
            name="firstName" 
            label="Name" 
            fullWidth 
            value={formData.firstName}
            onChange={handleFormChange}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField 
            required 
            id="lastName" 
            name="lastName" 
            label="Last Name" 
            fullWidth 
            value={formData.lastName}
            onChange={handleFormChange}
          />
        </Grid>
        <Grid item xs={12}>
          <TextField 
            required 
            id="address1" 
            name="address1" 
            label="Address 1" 
            fullWidth 
            value={formData.address1}
            onChange={handleFormChange}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField 
            required 
            id="city" 
            name="city" 
            label="City" 
            fullWidth 
            value={formData.city}
            onChange={handleFormChange}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField 
            required 
            id="zip" 
            name="zip" 
            label="ZIP Code" 
            fullWidth 
            value={formData.zip}
            onChange={handleFormChange}
          />
        </Grid>
        <Grid item xs={12} sm={6}>
          <TextField 
            required 
            id="country" 
            name="country" 
            label="Country" 
            fullWidth 
            value={formData.country}
            onChange={handleFormChange}
          />
        </Grid>
      </Grid>
    </>
  );
};
export default AddressForm;