// src/components/CategoryPage.js
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { useParams } from 'react-router-dom'; 
import { Container, Typography, Grid, CircularProgress, Alert } from '@mui/material';
import ParfumCard from './ParfumCard';

const CategoryPage = () => {
  const { categoryName } = useParams();
  const [parfums, setParfums] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    setLoading(true); 
    const categoryUpper = categoryName.toUpperCase();
    const API_URL = `http://localhost:8080/api/parfums/category/${categoryUpper}`;

    axios.get(API_URL) 
      .then(response => {
        setParfums(response.data);
        setLoading(false);
        setError(null);
      })
      .catch(err => {
        console.error("Kategori ürünleri çekilirken hata:", err);
        setError(`'${categoryName.toUpperCase()}' kategorisine ait ürünler yüklenemedi.`);
        setLoading(false);
      });
  }, [categoryName]);

  if (loading) {
    return <Container sx={{ textAlign: 'center', mt: 5 }}><CircularProgress color="primary" /></Container>;
  }

  if (error) {
    return <Container sx={{ mt: 5 }}><Alert severity="error">{error}</Alert></Container>;
  }

  return (
    <Container maxWidth="lg" sx={{ mt: 4, mb: 4 }}>
      <Typography variant="h4" component="h1" gutterBottom align="center" color="primary">
        {categoryName.toUpperCase()} Fragrances ({parfums.length} Product)
      </Typography>

      <Grid container spacing={4} justifyContent="center">
        {parfums.map((parfum) => (
          <Grid item key={parfum.id} xs={12} sm={6} md={4} lg={3}>
            <ParfumCard parfum={parfum} /> 
          </Grid>
        ))}
      </Grid>
    </Container>
  );
};

export default CategoryPage;