// src/components/Footer.js
import React from 'react';
import { Container, Box, Typography, Grid, Link, TextField, Button, Divider, IconButton } from '@mui/material';
import EmailIcon from '@mui/icons-material/Email';
import PhoneIcon from '@mui/icons-material/Phone';
import LocationOnIcon from '@mui/icons-material/LocationOn';
import SecurityIcon from '@mui/icons-material/Security';
import { Link as RouterLink } from 'react-router-dom';

// Quick Links Data
const sections = [
  { 
    title: "SHOPPING", 
    links: [
      { name: "KVKK Law", path: "/kvkk" }, 
      { name: "Privacy Agreement", path: "/gizlilik" }, 
      { name: "Cookie Policy", path: "/cerez" },
      { name: "Sales Policy Agreement", path: "/satis-sozlesmesi" }
    ] 
  },
  { 
    title: "SERVICES", 
    links: [
      { name: "Help", path: "/yardim" }, 
      { name: "Requests & Suggestions", path: "/oneriler" }, 
      { name: "Order Tracking", path: "/takip" }
    ] 
  },
  { 
    title: "CONTACT", 
    links: [
      { name: "About Us", path: "/info" }, 
      { name: "Contact", path: "/iletisim" }
    ] 
  }
];

const Footer = () => {
  return (
    <Box sx={{ 
      bgcolor: '#3c3c3c',
      color: 'white', 
      py: 5, 
      mt: 8, 
      borderTop: '5px solid #4e342e'
    }}>
      <Container maxWidth="lg">

        {/* 1. Newsletter Subscription Area */}
        <Grid container spacing={4} alignItems="center" sx={{ mb: 4, pb: 3, borderBottom: '1px solid #555' }}>
          <Grid item xs={12} md={6}>
            <Typography variant="body1" sx={{ fontWeight: 600 }}>NEWSLETTER</Typography>
            <Typography variant="caption">STAY INFORMED ABOUT NEW AND DISCOUNTED PRODUCTS!</Typography>
          </Grid>
          <Grid item xs={12} md={6}>
          </Grid>
        </Grid>

        {/* 2. Quick Links and Contact Information */}
        <Grid container spacing={4}>

          {/* Link Groups */}
          {sections.map((section) => (
            <Grid item xs={6} sm={4} md={2} key={section.title}>
              <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1.5, color: '#f5f5f5' }}>
                {section.title}
              </Typography>
              {section.links.map((link) => (
                <Link 
                  component={RouterLink} 
                  to={link.path} 
                  key={link.name}
                  color="inherit" 
                  variant="body2" 
                  display="block" 
                  sx={{ mb: 0.5, textDecoration: 'none', '&:hover': { textDecoration: 'underline', color: 'secondary.main' } }}
                >
                  {link.name}
                </Link>
              ))}
            </Grid>
          ))}

          {/* Contact Details */}
          <Grid item xs={12} sm={6} md={6}>
            <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 1.5, color: '#f5f5f5' }}>
                CONTACT / ADDRESS
            </Typography>

            {/* Address */}
            <Box display="flex" alignItems="flex-start" mb={1}>
                <LocationOnIcon color="secondary" sx={{ mr: 1, mt: 0.5 }} />
                <Typography variant="body2">
                    Altunizade, Kuşbakışı St. No:2, 34662 Üsküdar / Istanbul
                </Typography>
            </Box>

            {/* Phone */}
            <Box display="flex" alignItems="center" mb={1}>
                <PhoneIcon color="secondary" sx={{ mr: 1 }} />
                <Typography variant="body2">
                    PHONE: +90 553 804 78 90
                </Typography>
            </Box>

            {/* Email */}
            <Box display="flex" alignItems="center">
                <EmailIcon color="secondary" sx={{ mr: 1 }} />
                <Typography variant="body2">
                    E-MAIL: info@mdparfums.com
                </Typography>
            </Box>
          </Grid>

        </Grid>

        {/* Security */}
        <Divider sx={{ my: 4, bgcolor: '#555' }} />
        <Box display="flex" justifyContent="space-between" alignItems="center" flexWrap="wrap">
            <Typography variant="caption" sx={{ color: '#aaa' }}>
                Copyright 2025 MD Parfums. All rights reserved.
                Your credit card information is protected with a 256-bit SSL certificate.
            </Typography>
            <Box display="flex" alignItems="center">
                <SecurityIcon color="success" sx={{ mr: 0.5 }} />
                <Typography variant="caption" color="success">
                    Secure Shopping
                </Typography>
            </Box>
        </Box>

      </Container>
    </Box>
  );
};

export default Footer;
