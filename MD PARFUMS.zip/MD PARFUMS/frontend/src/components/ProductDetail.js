// src/components/ProductDetail.js
import React, { useState, useEffect, useMemo } from 'react';
import axios from 'axios';
import { useParams, useNavigate } from 'react-router-dom';
import { 
    Container, Typography, Grid, CircularProgress, Alert, Box, Button, Divider, Paper, 
    Rating, FormControl, InputLabel, Select, MenuItem 
} from '@mui/material';
import ShoppingCartIcon from '@mui/icons-material/ShoppingCart';
import { useCart } from './CartContext';
import CommentForm from './CommentForm';
import ReviewList from './ReviewList';

// Functions for Loading/Saving Reviews from Local Storage
const getProductReviews = (productId) => {
    const allReviews = JSON.parse(localStorage.getItem('all_product_reviews') || '{}');
    return allReviews[productId] || []; 
};

const saveProductReview = (productId, newReview) => {
    const allReviews = JSON.parse(localStorage.getItem('all_product_reviews') || '{}');
    const currentReviews = allReviews[productId] || [];
    const updatedReviews = [newReview, ...currentReviews];
    allReviews[productId] = updatedReviews;
    localStorage.setItem('all_product_reviews', JSON.stringify(allReviews));
    return updatedReviews;
};

const ProductDetail = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    const { addToCart, showSnackbar } = useCart(); 

    const [product, setProduct] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);
    const [reviews, setReviews] = useState([]); 
    const [averageRating, setAverageRating] = useState(0);
    
    // 1. Volume State (50 ml or 100 ml)
    const [selectedVolume, setSelectedVolume] = useState(50); 
    // 2. Quantity State (From 1 to 10)
    const [quantity, setQuantity] = useState(1); 
    
    const unitPrice = useMemo(() => {
        if (!product) return 0;
        
        let price = product.price;
        if (selectedVolume === 100) {
            price = price * 1.70;
        }
        return price;
    }, [product, selectedVolume]);
    
    // Total Price Calculation
    const totalPrice = useMemo(() => {
        return unitPrice * quantity;
    }, [unitPrice, quantity]);

    const addReview = (newReview) => {
        const updatedReviews = saveProductReview(id, newReview); 
        setReviews(updatedReviews);
        
        const newAvg = (updatedReviews.reduce((sum, r) => sum + r.rating, 0) / updatedReviews.length).toFixed(1);
        setAverageRating(newAvg);
    };

    useEffect(() => {
        const fetchProductData = async () => {
            const API_URL = `http://localhost:8080/api/parfums/${id}`; 
            
            try {
                const response = await axios.get(API_URL);
                setProduct(response.data);
                
                const storedReviews = getProductReviews(id);
                setReviews(storedReviews);

                const avg = storedReviews.length > 0 
                    ? (storedReviews.reduce((sum, r) => sum + r.rating, 0) / storedReviews.length).toFixed(1)
                    : 0;
                setAverageRating(avg);

                setLoading(false);
            } catch (err) {
                console.error("Error while fetching product details:", err);
                setError("Product not found or a server error occurred.");
                setLoading(false);
            }
        };

        fetchProductData();
    }, [id]); 

    if (loading) {
        return <Container sx={{ textAlign: 'center', mt: 5 }}><CircularProgress color="primary" /></Container>;
    }

    if (error) {
        return (
             <Container sx={{ mt: 5, textAlign: 'center' }}>
                <Alert severity="error">{error}</Alert>
                <Button variant="outlined" sx={{ mt: 2 }} onClick={() => navigate('/')}>Return to Home</Button>
             </Container>
        );
    }

    if (!product) {
        return <Container sx={{ mt: 5 }}><Alert severity="info">Product information could not be loaded.</Alert></Container>;
    }

    const handleAddToCart = () => {
        addToCart({
            ...product,
            price: unitPrice, 
            volume: selectedVolume, 
            quantity: quantity, 
            id: `${product.id}-${selectedVolume}ml`, 
            originalId: product.id,
            name: `${product.name} (${selectedVolume} ml)`
        });
        
        showSnackbar({
            message: `${quantity} unit(s) of ${product.name} (${selectedVolume} ml) added to cart!`,
            severity: 'success'
        });
    };

    return (
        <Container maxWidth="lg" sx={{ mt: 4, mb: 8 }}>
            
            <Paper elevation={2} sx={{ p: { xs: 2, md: 4 } }}> 
                <Grid container spacing={5}> 
                    
                    {/* 1. Image Section */}
                    <Grid 
                        item 
                        xs={12} 
                        md={5} 
                        sx={{ display: 'flex', justifyContent: 'center', alignItems: 'flex-start' }}
                    >
                        <Box sx={{ maxWidth: 350, width: '100%', height: 'auto' }}>
                            <Box 
                                component="img" 
                                src={product.imageUrl || 'placeholder.jpg'}
                                alt={product.name}
                                sx={{ 
                                    width: '100%', height: 'auto', borderRadius: 2, boxShadow: 5, objectFit: 'cover'
                                }}
                            />
                        </Box>
                    </Grid>

                    {/* 2. Details and Action Section */}
                    <Grid item xs={12} md={7}>
                        <Typography variant="h3" component="h1" gutterBottom sx={{ fontWeight: 700, color: 'primary.dark' }}>
                            {product.name}
                        </Typography>
                        <Typography variant="h5" color="text.secondary" gutterBottom sx={{ mb: 1 }}>
                            {product.brand}
                        </Typography>
                        
                        <Box display="flex" alignItems="center" sx={{ mb: 3 }}>
                            <Rating value={parseFloat(averageRating)} readOnly precision={0.5} sx={{ mr: 1 }} />
                            <Typography variant="body2" color="text.secondary">
                                ({reviews.length} reviews)
                            </Typography>
                        </Box>

                        <Divider sx={{ my: 3 }} />
                        
                        {/* PRICE DISPLAY */}
                        <Typography variant="h5" color="text.secondary" sx={{ mb: 1 }}>
                            Unit Price: {unitPrice.toFixed(2)} TL
                        </Typography>
                         <Typography variant="h4" color="error.main" sx={{ fontWeight: 700, mb: 3 }}>
                            Total Price: {totalPrice.toFixed(2)} TL
                        </Typography>

                        {/* Action Area: Volume, Quantity, and Cart */}
                        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 4, flexWrap: 'wrap' }}>
                            
                            <FormControl variant="outlined" sx={{ minWidth: 140 }} size="small">
                                <InputLabel id="volume-select-label">Size</InputLabel>
                                <Select
                                    labelId="volume-select-label"
                                    value={selectedVolume}
                                    onChange={(e) => setSelectedVolume(e.target.value)}
                                    label="Size"
                                >
                                    <MenuItem value={50}>50 ml</MenuItem>
                                    <MenuItem value={100}>100 ml (+70%)</MenuItem>
                                </Select>
                            </FormControl>

                            <FormControl variant="outlined" sx={{ minWidth: 120 }} size="small">
                                <InputLabel id="quantity-select-label">Qty</InputLabel>
                                <Select
                                    labelId="quantity-select-label"
                                    value={quantity}
                                    onChange={(e) => setQuantity(e.target.value)}
                                    label="Qty"
                                >
                                    {Array.from({ length: 10 }, (_, i) => i + 1).map(num => (
                                        <MenuItem key={num} value={num}>
                                            {num} {num > 1 ? 'Units' : 'Unit'}
                                        </MenuItem>
                                    ))}
                                </Select>
                            </FormControl>

                            <Button 
                                variant="contained" color="primary" size="large" 
                                startIcon={<ShoppingCartIcon />}
                                onClick={handleAddToCart}
                                sx={{ py: 1.5, flexGrow: 1, minWidth: 150 }} 
                            >
                                Add to Cart
                            </Button>
                        </Box>

                        <Divider sx={{ my: 3 }} />

                        {/* Description */}
                        <Typography variant="h6" component="h2" sx={{ fontWeight: 600, mt: 3, mb: 1 }}>
                            Product Details
                        </Typography>
                        <Typography variant="body1" paragraph>
                            {product.description}
                        </Typography>
                        
                        {/* Legal/Category Info */}
                        <Box sx={{ mt: 3, bgcolor: '#f5f5f5', p: 2, borderRadius: 1 }}>
                            <Typography variant="caption" color="text.secondary" display="block">
                                Category: {product.category}
                            </Typography>
                            <Typography variant="caption" color="text.secondary" display="block">
                                This product is manufactured in compliance with Ministry of Health regulations.
                            </Typography>
                        </Box>
                    </Grid>
                </Grid>
            </Paper>
            
            {/* Reviews Section */}
            <Paper elevation={2} sx={{ p: { xs: 2, md: 4 }, mt: 4 }}>
                <CommentForm productId={product.id} addReview={addReview} />
                <Divider sx={{ mt: 4 }} />
                <ReviewList reviews={reviews} averageRating={averageRating} />
            </Paper>
            
        </Container>
    );
};

export default ProductDetail;