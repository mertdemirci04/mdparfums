// src/components/LoginForm.js
import React, { useState } from 'react';
import { TextField, Button, Box, Alert, CircularProgress, Typography } 
from '@mui/material';
import { useNavigate } from 'react-router-dom';
import { useAuth } from './AuthContext';

const LoginForm = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  
  const { login } = useAuth();
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
      e.preventDefault();
      setError('');
      setLoading(true);
      
      try {
        await login(email, password);
        navigate('/');
      } catch (err) {
        const errorMessage = typeof err === 'string' 
            ? err 
            : (err && err.message) ? err.message : 'An unknown login error occurred.';
        
        setError(errorMessage); // Store as text only
      } finally {
        setLoading(false);
      }
    };

  return (
    <Box component="form" onSubmit={handleSubmit} sx={{ display: 'grid', gap: 2 }}>
      <TextField
        required
        label="Email"
        type="email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        fullWidth
      />
      <TextField
        required
        label="Password"
        type="password"
        value={password}
        onChange={(e) => setPassword(e.target.value)}
        fullWidth
      />
      
      {error && <Alert severity="error">{error}</Alert>}
      
      <Button
        type="submit"
        variant="contained"
        color="primary"
        size="large"
        disabled={loading}
        sx={{ mt: 2 }}
      >
        {loading ? <CircularProgress size={24} color="inherit" /> : 'Login'}
      </Button>
      <Box sx={{ textAlign: 'center', mt: 1 }}>
        <Typography variant="caption"></Typography>
      </Box>
    </Box>
  );
};

export default LoginForm;