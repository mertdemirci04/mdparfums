// src/components/AnnouncementBar.js
import React from 'react';
import { Box, Typography } from '@mui/material';

const AnnouncementBar = () => {
  return (
    <Box 
      sx={{
        bgcolor: 'secondary.dark',
        color: 'white',
        textAlign: 'center',
        py: 0.5,
        px: 2,
      }}
    >
      <Typography 
        variant="caption" 
        sx={{ 
          fontWeight: 700,
          fontSize: '0.8rem',        }}
      >
        FREE SHIPPING ON ORDERS OVER 1000 TL! 🚚 &nbsp; | &nbsp; BUY 6 PERFUMES, GET 1 FREE! 🎁
      </Typography>
    </Box>
  );
};

export default AnnouncementBar;