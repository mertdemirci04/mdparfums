// src/components/PaymentForm.js
import React from 'react';
import { Typography, Grid, TextField, Box } from '@mui/material';

const PaymentForm = ({ formData, handleFormChange }) => {

  const onInputChange = (e) => {
    const { name, value } = e.target;

    // 1. Card Name
    if (name === "cardName") {
      const formattedValue = value.replace(/[^a-zA-ZğüşıöçĞÜŞİÖÇ ]/g, "");
      e.target.value = formattedValue;
    }

    // 2. Card Number
    if (name === "cardNumber") {
      const formattedValue = value.replace(/\D/g, "");
      e.target.value = formattedValue;
    }

    // 3. Expiry Date
    if (name === "expDate") {
      let formattedValue = value.replace(/\D/g, ""); // Sayı dışındakileri sil
      if (formattedValue.length > 2) {
        formattedValue = `${formattedValue.slice(0, 2)}/${formattedValue.slice(2, 4)}`;
      }
      e.target.value = formattedValue;
    }

    if (name === "cvv") {
      const formattedValue = value.replace(/\D/g, "").slice(0, 3);
      e.target.value = formattedValue;
    }

    handleFormChange(e);
  };

  return (
    <React.Fragment>
      <Typography variant="h6" gutterBottom>
        Payment Method
      </Typography>
      <Grid container spacing={3}>
        
        {/* Name on Card */}
        <Grid item xs={12} md={6}>
          <TextField
            required
            id="cardName"
            name="cardName"
            label="Name on Card"
            fullWidth
            variant="standard"
            value={formData.cardName}
            onChange={onInputChange}
          />
        </Grid>
        
        {/* Card Number */}
        <Grid item xs={12} md={6}>
          <TextField
            required
            id="cardNumber"
            name="cardNumber"
            label="Card Number"
            fullWidth
            variant="standard"
            inputProps={{ maxLength: 16 }}
            value={formData.cardNumber}
            onChange={onInputChange}
          />
        </Grid>
        
        {/* Expiry Date (MM/YY) */}
        <Grid item xs={12} md={6}>
          <TextField
            required
            id="expDate"
            name="expDate"
            label="Expiry Date (MM/YY)"
            placeholder="MM/YY"
            fullWidth
            variant="standard"
            inputProps={{ maxLength: 5 }}
            value={formData.expDate}
            onChange={onInputChange}
          />
        </Grid>
        
        {/* CVV */}
        <Grid item xs={12} md={6}>
          <TextField
            required
            id="cvv"
            name="cvv"
            label="CVV"
            fullWidth
            variant="standard"
            inputProps={{ maxLength: 3 }}
            value={formData.cvv}
            onChange={onInputChange}
          />
          <Box sx={{ mt: 1 }}>
             <Typography variant="caption" color="text.secondary">
                Last 3 digits on the back of the card
             </Typography>
          </Box>
        </Grid>
        
        <Grid item xs={12}>
            <Typography variant="caption" color="text.secondary">
                All your card information is secured with 256-bit SSL encryption.
            </Typography>
        </Grid>

      </Grid>
    </React.Fragment>
  );
};

export default PaymentForm;