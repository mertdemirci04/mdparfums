// src/components/OrdersPage.js
import React, { useEffect, useState } from 'react';
import { Container, Typography, Paper, Table, TableBody, TableCell, TableContainer, TableHead, TableRow, Button, Alert, Box, IconButton, Dialog, DialogActions, DialogContent, DialogContentText, DialogTitle } from '@mui/material';
import { useAuth } from './AuthContext';
import { useNavigate } from 'react-router-dom';
import DeleteIcon from '@mui/icons-material/Delete';

const getMyOrders = (userId) => {
    if (!userId) return [];
    const allOrders = JSON.parse(localStorage.getItem('all_orders') || '[]');
    return allOrders.filter(order => order.userId === userId).reverse();
};

const deleteOrderFromLocalStorage = (orderId) => {
    const allOrders = JSON.parse(localStorage.getItem('all_orders') || '[]');
    const updatedOrders = allOrders.filter(order => order.id !== orderId);
    localStorage.setItem('all_orders', JSON.stringify(updatedOrders));
};


const OrdersPage = () => {
    const { user, isAuthenticated } = useAuth();
    const [orders, setOrders] = useState([]);
    const [openDialog, setOpenDialog] = useState(false);
    const [orderToCancel, setOrderToCancel] = useState(null);
    const navigate = useNavigate();

    // Loading Orders
    useEffect(() => {
        if (!isAuthenticated || !user) {
            navigate('/login');
            return;
        }

        const fetchOrders = () => {
            setOrders(getMyOrders(user.id));
        };

        fetchOrders();
    }, [isAuthenticated, user, navigate]);


    // Click Cancel Button (Opens confirmation dialog)
    const handleOpenCancelDialog = (orderId) => {
        setOrderToCancel(orderId);
        setOpenDialog(true);
    };

    // Confirming Cancellation (Deletes from Local Storage)
    const handleConfirmCancel = () => {
        if (orderToCancel) {
            deleteOrderFromLocalStorage(orderToCancel);
            
            setOrders(prevOrders => prevOrders.filter(order => order.id !== orderToCancel));
            
            setOpenDialog(false);
            setOrderToCancel(null);
        }
    };

    const handleCloseDialog = () => {
        setOpenDialog(false);
        setOrderToCancel(null);
    };


    if (!isAuthenticated) {
        return (
            <Container maxWidth="md" sx={{ mt: 5, textAlign: 'center' }}>
                <Alert severity="error" sx={{ mb: 3 }}>Please log in to view your orders.</Alert>
                <Button variant="contained" color="primary" onClick={() => navigate('/login')}>
                    Login
                </Button>
            </Container>
        );
    }

    if (orders.length === 0) {
        return (
            <Container maxWidth="lg" sx={{ mt: 4, mb: 8 }}>
                <Typography variant="h4" component="h1" gutterBottom color="primary" sx={{ mb: 4, fontWeight: 700 }}>
                    My Orders
                </Typography>
                <Alert severity="info" sx={{ mt: 2, p: 3 }}>
                    You don't have any completed orders yet.
                </Alert>
            </Container>
        );
    }

    return (
        <Container maxWidth="lg" sx={{ mt: 4, mb: 8 }}>
            <Typography variant="h4" component="h1" gutterBottom color="primary" sx={{ fontWeight: 700, mb: 4 }}>
                My Orders
            </Typography>

            <TableContainer component={Paper} elevation={3}>
                <Table>
                    <TableHead>
                        <TableRow>
                            <TableCell sx={{ fontWeight: 'bold' }}>Order No</TableCell>
                            <TableCell align="center" sx={{ fontWeight: 'bold' }}>Date</TableCell>
                            <TableCell align="center" sx={{ fontWeight: 'bold' }}>Status</TableCell>
                            <TableCell align="right" sx={{ fontWeight: 'bold' }}>Total Amount</TableCell>
                            <TableCell align="center" sx={{ fontWeight: 'bold' }}>Actions</TableCell>
                        </TableRow>
                    </TableHead>
                    <TableBody>
                        {orders.map((order) => (
                            <TableRow key={order.id}>
                                <TableCell>{order.id}</TableCell>
                                <TableCell align="center">{order.date}</TableCell>
                                <TableCell align="center">
                                    <Box component="span" sx={{ 
                                        color: order.status === 'Preparing' ? 'orange' : 'green',
                                        fontWeight: 'bold'
                                    }}>
                                        {order.status === 'Hazırlanıyor' ? 'Preparing' : 
                                         order.status === 'Teslim Edildi' ? 'Delivered' : order.status}
                                    </Box>
                                </TableCell>
                                <TableCell align="right">${order.total}</TableCell>
                                <TableCell align="center">
                                    <Box display="flex" justifyContent="center" gap={1}>
                                        <Button 
                                            variant="outlined" 
                                            size="small"
                                            onClick={() => navigate(`/order/detail/${order.id}`)}
                                        >
                                            View Details
                                        </Button>
                                        
                                        {/* Cancel Button */}
                                        {order.status !== 'Teslim Edildi' && order.status !== 'Delivered' && (
                                            <IconButton 
                                                color="error" 
                                                size="small"
                                                onClick={() => handleOpenCancelDialog(order.id)}
                                            >
                                                <DeleteIcon fontSize="small" />
                                            </IconButton>
                                        )}
                                    </Box>
                                </TableCell>
                            </TableRow>
                        ))}
                    </TableBody>
                </Table>
            </TableContainer>
            
            {/* ORDER CANCELLATION CONFIRMATION DIALOG */}
            <Dialog
                open={openDialog}
                onClose={handleCloseDialog}
                aria-labelledby="alert-dialog-title"
                aria-describedby="alert-dialog-description"
            >
                <DialogTitle id="alert-dialog-title">
                    {"Confirm Order Cancellation"}
                </DialogTitle>
                <DialogContent>
                    <DialogContentText id="alert-dialog-description">
                        Are you sure you want to cancel order {orderToCancel ? `#${orderToCancel}` : ''}? This action cannot be undone.
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={handleCloseDialog} color="primary">
                        Cancel
                    </Button>
                    <Button onClick={handleConfirmCancel} color="error" variant="contained" autoFocus>
                        Confirm Cancellation
                    </Button>
                </DialogActions>
            </Dialog>

        </Container>
    );
};

export default OrdersPage;