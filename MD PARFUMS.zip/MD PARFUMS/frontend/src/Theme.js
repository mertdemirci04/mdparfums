// src/Theme.js
import { createTheme } from '@mui/material/styles';

const theme = createTheme({
  palette: {
    primary: {
      main: '#4e342e', // Koyu Kahverengi (Marka Rengi)
    },
    secondary: {
      main: '#bcaaa4', // Açık Kahverengi/Bej (Vurgu Rengi)
    },
    background: {
      default: '#fafafa', // Hafif Kirli Beyaz
    },
  },
  typography: {
    fontFamily: 'Roboto, Arial, sans-serif',
    h4: {
      fontWeight: 600,
    },
  },
});

export default theme;