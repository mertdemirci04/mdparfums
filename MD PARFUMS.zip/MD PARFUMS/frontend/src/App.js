// src/App.js
import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';

import Header from './components/Header';
import HomePage from './components/HomePage';
import AllParfumsPage from './components/AllParfumsPage';
import CategoryPage from './components/CategoryPage';
import Footer from './components/Footer';
import CartPage from './components/CartPage';
import AnnouncementBar from './components/AnnouncementBar';
import ProductDetail from './components/ProductDetail';
import SearchResultsPage from './components/SearchResultsPage';
import LoginRegisterPage from './components/LoginRegisterPage';
import InfoContentPage from './components/InfoContentPage'; 
import CheckoutPage from './components/CheckoutPage';
import ProfilePage from './components/ProfilePage';
import OrdersPage from './components/OrdersPage';
import SettingsPage from './components/SettingsPage';
import OrderDetailPage from './components/OrderDetailPage';

import { INFO_PAGES } from './InfoData';

import { CssBaseline, Snackbar, Typography } from '@mui/material';
import MuiAlert from '@mui/material/Alert';

import { CartProvider, useCart } from './components/CartContext';
import { AuthProvider } from './components/AuthContext';


const Alert = React.forwardRef(function Alert(props, ref) {
    return <MuiAlert elevation={6} ref={ref} variant="filled" {...props} />;
});

function AppContent() {
    const { snackbar, closeSnackbar } = useCart();

    return (
        <>
            <CssBaseline />
            
            {/* GLOBAL */}
            <AnnouncementBar />
            <Header />  
            
            {/* (Routes) */}
            <Routes>
                <Route path="/" element={<HomePage />} />
                <Route path="/parfum" element={<AllParfumsPage />} />
                <Route path="/category/:categoryName" element={<CategoryPage />} />
                <Route path="/sepet" element={<CartPage />} />
                <Route path="/product/:id" element={<ProductDetail />} /> 
                <Route path="/search" element={<SearchResultsPage />} />
                <Route path="/login" element={<LoginRegisterPage />} />
                
                <Route path="/odeme" element={<CheckoutPage />} /> 

                <Route path="/profil" element={<ProfilePage />} />
                <Route path="/siparislerim" element={<OrdersPage />} />
                <Route path="/profil/ayarlar" element={<SettingsPage />} /> 
                <Route path="/order/detail/:id" element={<OrderDetailPage />} />
                
                {Object.keys(INFO_PAGES).map(path => (
                    <Route key={path} path={path} element={<InfoContentPage />} />
                ))}
            </Routes>
            
            <Footer />
            
            {/* Snackbar */}
            <Snackbar 
                open={snackbar.open} 
                autoHideDuration={3000} 
                onClose={closeSnackbar} 
                anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
            >
                <Alert onClose={closeSnackbar} severity={snackbar.severity} sx={{ width: '100%' }}>
                    {snackbar.message}
                </Alert>
            </Snackbar>
        </>
    );
}

export default function App() {
    return (
        <Router> 
            <CartProvider>
                <AuthProvider>
                    <AppContent /> 
                </AuthProvider>
            </CartProvider>
        </Router>
    );
}